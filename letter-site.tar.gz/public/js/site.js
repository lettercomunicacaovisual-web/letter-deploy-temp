/* Letter — site público (SPA sem dependências). O conteúdo vem do painel administrativo. */
(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const safeUrl = u => { u = String(u || '').trim(); return /^(https?:\/\/|\/(?!\/)|mailto:|tel:|#)/i.test(u) ? u : ''; };
const C = JSON.parse($('#boot').textContent);
const B = C.brand;

/* ---------- ícones ---------- */
const S = (p, extra = '') => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${p}</svg>`;
const ICON = {
  chev: '<svg class="chev" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 4l6 6-6 6"/></svg>',
  menu: S('<path d="M4 8h16M4 16h16"/>', 'width="26" height="26"'),
  close: S('<path d="M6 6l12 12M18 6L6 18"/>', 'width="26" height="26"'),
  wa: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.16-.17.2-.35.22-.65.08-.3-.15-1.26-.46-2.39-1.48-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.6.13-.14.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.03-.52-.07-.15-.67-1.61-.92-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.21 3.07c.15.2 2.1 3.2 5.08 4.49.71.3 1.26.49 1.69.63.71.23 1.36.2 1.87.12.57-.09 1.76-.72 2-1.41.25-.7.25-1.29.17-1.41-.07-.12-.27-.2-.57-.35M12.05 21.79a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.86 9.86 0 0 1-1.51-5.26c0-5.45 4.44-9.88 9.89-9.88 2.64 0 5.12 1.03 6.99 2.9a9.83 9.83 0 0 1 2.89 6.99c0 5.45-4.44 9.88-9.89 9.88M20.46 3.49A11.8 11.8 0 0 0 12.05 0C5.5 0 .16 5.34.16 11.89c0 2.1.55 4.14 1.59 5.95L.06 24l6.3-1.65a11.9 11.9 0 0 0 5.69 1.45h.01c6.55 0 11.89-5.34 11.89-11.89 0-3.18-1.24-6.17-3.48-8.42"/></svg>',
  instagram: S('<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.3" cy="6.7" r=".7" fill="currentColor"/>'),
  facebook: S('<path d="M14 8h3V4h-3a4 4 0 0 0-4 4v2H7v4h3v6h4v-6h3l1-4h-4V8z"/>'),
  linkedin: S('<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 10.5V16M8 7.6v.01M12 16v-5.5M12 13c0-1.6 1-2.5 2.5-2.5S17 11.4 17 13v3"/>'),
  youtube: S('<rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path d="M10 9.5l5 2.5-5 2.5z"/>')
};

/* ---------- utilidades de conteúdo ---------- */
const digits = s => String(s || '').replace(/\D/g, '');
const waLink = msg => `https://api.whatsapp.com/send/?phone=${digits(B.whatsapp)}&text=${encodeURIComponent(msg ?? B.whatsappMessage ?? '')}`;
const fmtDate = d => { const t = new Date(String(d).slice(0, 10) + 'T12:00:00'); return isNaN(t) ? '' : t.toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' }); };
const paras = t => String(t || '').split(/\n{2,}/).map(p => p.trim()).filter(Boolean).map(p => `<p>${esc(p).replace(/\n/g, '<br>')}</p>`).join('');
function inline(s) {
  return esc(s).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
    .replace(/\[([^\]]+)\]\((\/[^)\s]*)\)/g, '<a href="$2">$1</a>');
}
function md(t) {
  const out = []; let list = [], para = [];
  const fp = () => { if (para.length) { out.push('<p>' + inline(para.join(' ')) + '</p>'); para = []; } };
  const fl = () => { if (list.length) { out.push('<ul>' + list.map(i => '<li>' + inline(i) + '</li>').join('') + '</ul>'); list = []; } };
  for (const raw of String(t || '').split('\n')) {
    const l = raw.trim(); let m;
    if (!l) { fp(); fl(); continue; }
    if ((m = /^##\s+(.*)/.exec(l))) { fp(); fl(); out.push('<h2>' + inline(m[1]) + '</h2>'); }
    else if ((m = /^[-*]\s+(.*)/.exec(l))) { fp(); list.push(m[1]); }
    else { fl(); para.push(l); }
  }
  fp(); fl(); return out.join('');
}

/* mídia: imagem, vídeo enviado (.mp4/.webm) ou link do YouTube/Vimeo; vazio = espaço reservado */
function media(src, alt, o = {}) {
  src = safeUrl(src);
  if (!src) return `<div class="ph" role="img" aria-label="${esc(alt)}"></div>`;
  let m;
  if ((m = /(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{11})/.exec(src))) {
    const id = m[1];
    const q = o.controls ? 'autoplay=1&rel=0' : `autoplay=1&mute=1&loop=1&playlist=${id}&controls=0&modestbranding=1&rel=0&playsinline=1`;
    return `<iframe src="https://www.youtube-nocookie.com/embed/${id}?${q}" title="${esc(alt)}" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen loading="lazy"></iframe>`;
  }
  if ((m = /vimeo\.com\/(?:video\/)?(\d+)/.exec(src))) {
    return `<iframe src="https://player.vimeo.com/video/${m[1]}?${o.controls ? 'autoplay=1' : 'background=1&autoplay=1&loop=1&muted=1'}" title="${esc(alt)}" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen loading="lazy"></iframe>`;
  }
  if (/\.(mp4|webm)(\?|$)/i.test(src)) {
    return o.controls ? `<video src="${esc(src)}" controls autoplay playsinline></video>` : o.still ? `<video src="${esc(src)}#t=0.1" muted playsinline preload="metadata"></video>` : `<video src="${esc(src)}" autoplay muted loop playsinline preload="metadata"></video>`;
  }
  return `<img src="${esc(src)}" alt="${esc(alt)}" loading="${o.eager ? 'eager' : 'lazy'}" decoding="async">`;
}
const isVideoFile = s => /\.(mp4|webm)(\?|$)/i.test(s || '');
const thumb = (it, alt) => it.image ? media(it.image, alt) : isVideoFile(it.video) ? media(it.video, alt, { still: true }) : media('', alt);

/* ---------- cabeçalho, rodapé, WhatsApp ---------- */
const logoSrc = safeUrl(B.logo) || '/assets/logo.svg';
function renderChrome() {
  const items = (C.nav || []).filter(n => n.visible);
  $('#header').innerHTML = `<div class="container header-in">
    <a class="logo" href="/" aria-label="${esc(B.name)} — página inicial"><img src="${esc(logoSrc)}" alt="${esc(B.name)}" height="26"></a>
    <nav class="nav" aria-label="Principal">${items.map(n => `<a href="${esc(n.path)}">${esc(n.label)}</a>`).join('')}</nav>
    <div class="header-cta"><a class="btn sm" href="/orcamento">${esc(C.header.cta)}</a>
    <button class="menu-btn" aria-label="Abrir menu" aria-expanded="false" aria-controls="drawer">${ICON.menu}</button></div></div>`;
  const d = document.createElement('div');
  d.className = 'drawer'; d.id = 'drawer'; d.setAttribute('role', 'dialog'); d.setAttribute('aria-label', 'Menu');
  d.innerHTML = `<button class="drawer-close" aria-label="Fechar menu">${ICON.close}</button>${items.map(n => `<a class="d-link" href="${esc(n.path)}">${esc(n.label)}</a>`).join('')}<a class="btn" href="/orcamento">${esc(C.header.cta)}</a>`;
  document.body.appendChild(d);
  const open = v => { d.classList.toggle('open', v); $('.menu-btn').setAttribute('aria-expanded', v); document.body.style.overflow = v ? 'hidden' : ''; };
  $('.menu-btn').addEventListener('click', () => open(true));
  $('.drawer-close', d).addEventListener('click', () => open(false));
  d.addEventListener('click', e => { if (e.target.closest('a')) open(false); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') open(false); });

  const soc = [['instagram', B.instagram, 'Instagram'], ['facebook', B.facebook, 'Facebook'], ['linkedin', B.linkedin, 'LinkedIn'], ['youtube', B.youtube, 'YouTube']]
    .filter(s => safeUrl(s[1])).map(s => `<a href="${esc(safeUrl(s[1]))}" target="_blank" rel="noopener noreferrer" aria-label="${s[2]}">${ICON[s[0]]}</a>`).join('');
  const contact = [B.phone && `<li><a href="tel:+${digits(B.phone.length > 11 ? B.phone : '55' + B.phone)}">${esc(B.phone)}</a></li>`, B.email && `<li><a href="mailto:${esc(B.email)}">${esc(B.email)}</a></li>`, B.address && `<li>${esc(B.address)}</li>`, B.hours && `<li>${esc(B.hours)}</li>`].filter(Boolean).join('');
  $('#footer').innerHTML = `<div class="container"><div class="foot-top">
    <div class="foot-logo"><img class="${B.logoLight ? 'native' : ''}" src="${esc(safeUrl(B.logoLight) || logoSrc)}" alt="${esc(B.name)}"><p>${esc(C.footer.text)}</p>${soc ? `<div class="social">${soc}</div>` : ''}</div>
    <div><h4>Navegue</h4><ul>${items.map(n => `<li><a href="${esc(n.path)}">${esc(n.label)}</a></li>`).join('')}<li><a href="/orcamento">${esc(C.quote.title)}</a></li></ul></div>
    <div><h4>Soluções</h4><ul>${C.solutions.items.slice(0, 6).map(s => `<li><a href="/solucoes#${esc(s.slug)}">${esc(s.title)}</a></li>`).join('')}</ul></div>
    <div><h4>Contato</h4><ul>${contact}</ul></div></div>
    <div class="foot-bottom"><span>© ${new Date().getFullYear()} ${esc(B.name)}${B.descriptor ? ' ' + esc(B.descriptor) : ''}. ${esc(C.footer.copyright)}</span>
    <span><a href="/privacidade">${esc(C.privacy.title)}</a> · <button type="button" id="cookie-prefs">Preferências de cookies</button></span></div></div>`;
  $('#wa').innerHTML = `<a class="wa" href="${esc(waLink())}" target="_blank" rel="noopener noreferrer" aria-label="Conversar pelo WhatsApp">${ICON.wa}</a>`;
  $('#cookie-prefs').addEventListener('click', () => cookieBanner(true));
  const onScroll = () => $('#header').classList.toggle('scrolled', scrollY > 8);
  addEventListener('scroll', onScroll, { passive: true }); onScroll();
}

/* ---------- blocos reutilizáveis ---------- */
const ctaBand = (title, text, label, href = '/orcamento') => `<section class="cta-band"><div class="container"><h2>${esc(title)}</h2>${text ? `<p>${esc(text)}</p>` : ''}<p><a class="btn light" href="${href}">${esc(label)}</a></p></div></section>`;
const pageHead = (title, sub) => `<section class="page-head container"><h1>${esc(title)}</h1>${sub ? `<p class="lead">${esc(sub)}</p>` : ''}</section>`;
const postCard = p => `<a class="post" href="/insights/${esc(p.slug)}"><div class="media r-3-2" style="aspect-ratio:3/2">${media(p.cover, p.title)}</div><div class="post-meta"><span>${esc(p.category)}</span><time>${esc(fmtDate(p.date))}</time></div><h3>${esc(p.title)}</h3><p>${esc(p.excerpt)}</p></a>`;
const pfCard = (it, i) => `<button class="pf" data-pf="${i}" aria-label="Ver projeto ${esc(it.title)}"><div class="media">${thumb(it, it.title)}</div><div class="pf-meta"><h3>${esc(it.title)}</h3><span>${esc(it.category)}</span></div></button>`;
const sortedPosts = () => [...C.insights.posts].sort((a, b) => String(b.date).localeCompare(String(a.date)));
const activeProducts = () => (C.products.items || []).filter(p => p.active !== false);

function field({ name, label, type = 'text', required, options, placeholder = '', value = '', rows }) {
  const id = 'f-' + name, req = required ? ' required' : '';
  let inp;
  if (options) inp = `<select id="${id}" name="${name}"${req}><option value="">Selecione</option>${options.map(o => `<option${o === value ? ' selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
  else if (type === 'textarea') inp = `<textarea id="${id}" name="${name}" rows="${rows || 5}"${req} placeholder="${esc(placeholder)}">${esc(value)}</textarea>`;
  else inp = `<input id="${id}" name="${name}" type="${type}"${req} placeholder="${esc(placeholder)}" value="${esc(value)}" ${type === 'tel' ? 'autocomplete="tel" inputmode="tel"' : ''} ${type === 'email' ? 'autocomplete="email"' : ''}>`;
  return `<div class="field"><label for="${id}">${esc(label)}${required ? '' : ' (opcional)'}</label>${inp}</div>`;
}
const formTail = label => `<div class="hp" aria-hidden="true"><label>Não preencha <input name="website" tabindex="-1" autocomplete="off"></label></div>
  <label class="consent-note"><input type="checkbox" name="consent" required> Li e concordo com a <a href="/privacidade" target="_blank" style="text-decoration:underline">política de privacidade</a>.</label>
  <div class="form-msg" role="status" aria-live="polite" hidden></div><div><button class="btn" type="submit">${esc(label)}</button></div>`;

function bindForm(form, type, done) {
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const btn = $('button[type=submit]', form), msg = $('.form-msg', form);
    btn.disabled = true; msg.hidden = true;
    const fd = new FormData(form), data = {};
    fd.forEach((v, k) => { if (k !== 'website' && k !== 'consent') data[k] = String(v).trim(); });
    try {
      const r = await fetch('/api/lead', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'letter' }, body: JSON.stringify({ type, website: fd.get('website'), data }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error || 'Não foi possível enviar agora. Tente novamente.');
      if (window.gtag && consent.a) gtag('event', 'generate_lead', { form_type: type });
      if (window.fbq && consent.m) fbq('track', 'Lead');
      done(data, form);
    } catch (err) { msg.textContent = err.message; msg.className = 'form-msg err'; msg.hidden = false; }
    finally { btn.disabled = false; }
  });
}
const okMsg = (form, text) => { const m = $('.form-msg', form); m.className = 'form-msg'; m.textContent = text; m.hidden = false; form.reset(); };

/* ---------- páginas ---------- */
function home() {
  const h = C.home, sol = C.solutions.items;
  const feat = C.portfolio.items.slice(0, Math.max(1, +h.featuredCount || 5));
  const posts = sortedPosts().slice(0, 3);
  return {
    title: '',
    html: `<section class="hero container"><h1>${esc(h.hero.title)}</h1>
      <div class="hero-row"><p class="lead">${esc(h.hero.subtitle)}</p><div class="hero-cta"><a class="btn" href="/orcamento">${esc(h.hero.cta1)}</a><a class="btn ghost" href="/portfolio">${esc(h.hero.cta2)}</a></div></div>
      <div class="media r-21-9">${media(h.hero.media, h.hero.title, { eager: true })}</div></section>
      <section class="statement container"><p>${esc(h.intro.text)}</p></section>
      <section class="section alt"><div class="container"><div class="section-head"><h2>${esc(h.solutionsTitle)}</h2><a class="link" href="/solucoes">${esc(h.solutionsLink)}</a></div>
        <div class="sol-index"><div class="sol-list">${sol.map((s, i) => `<a class="sol-row${i === 0 ? ' on' : ''}" href="/solucoes#${esc(s.slug)}" data-i="${i}"><h3>${esc(s.title)}</h3>${ICON.chev}<p>${esc(s.short)}</p></a>`).join('')}</div>
        <div class="sol-preview" aria-hidden="true"><div class="media">${sol.map((s, i) => `<div class="${i === 0 ? 'show' : ''}">${media(s.image, s.title)}</div>`).join('')}</div></div></div></div></section>
      ${feat.length ? `<section class="section"><div class="container"><div class="section-head"><h2>${esc(h.portfolioTitle)}</h2><a class="link" href="/portfolio">${esc(h.portfolioLink)}</a></div><div class="pf-grid feat">${feat.map((it, i) => pfCard(it, i)).join('')}</div></div></section>` : ''}
      ${posts.length ? `<section class="section alt"><div class="container"><div class="section-head"><h2>${esc(h.insightsTitle)}</h2><a class="link" href="/insights">${esc(h.insightsLink)}</a></div><div class="post-grid">${posts.map(postCard).join('')}</div></div></section>` : ''}
      ${ctaBand(h.cta.title, h.cta.text, h.cta.button)}`,
    after(root) {
      const rows = $$('.sol-row', root), shots = $$('.sol-preview .media>div', root);
      const pick = i => { rows.forEach((r, k) => r.classList.toggle('on', k === i)); shots.forEach((s, k) => s.classList.toggle('show', k === i)); };
      rows.forEach((r, i) => { r.addEventListener('mouseenter', () => pick(i)); r.addEventListener('focus', () => pick(i)); });
    }
  };
}

function solutions() {
  const S_ = C.solutions, prods = activeProducts().slice(0, 3);
  return {
    title: S_.title,
    html: `${pageHead(S_.title, S_.subtitle)}<div class="container">${S_.items.map(s => `<article class="sol-item" id="${esc(s.slug)}"><div class="sol-media"><div class="media">${media(s.image, s.title)}</div></div><div><h2>${esc(s.title)}</h2><p>${esc(s.description)}</p>${(s.features || []).length ? `<ul class="ticks">${s.features.map(f => `<li>${esc(f)}</li>`).join('')}</ul>` : ''}<a class="btn" href="/orcamento?servico=${encodeURIComponent(s.slug)}">${esc(S_.cta)}</a></div></article>`).join('')}</div>
      ${(S_.process || []).length ? `<section class="section alt"><div class="container"><div class="section-head"><h2>${esc(S_.processTitle)}</h2></div><div class="steps">${S_.process.map((p, i) => `<div class="step"><b>${i + 1}</b><h3>${esc(p.title)}</h3><p>${esc(p.text)}</p></div>`).join('')}</div></div></section>` : ''}
      ${prods.length ? `<section class="section"><div class="container"><div class="section-head"><h2>${esc(S_.productsTitle)}</h2><a class="link" href="/produtos">${esc(S_.productsLink)}</a></div><div class="prod-grid">${prods.map(prodCard).join('')}</div></div></section>` : ''}
      ${ctaBand(C.home.cta.title, C.home.cta.text, C.home.cta.button)}`,
    after() { if (location.hash) setTimeout(() => { const el = document.getElementById(decodeURIComponent(location.hash.slice(1))); el && el.scrollIntoView(); }, 30); }
  };
}

function portfolio() {
  const P = C.portfolio;
  return {
    title: P.title,
    html: `${pageHead(P.title, P.subtitle)}<section class="container" style="padding-bottom:clamp(4rem,8vw,7rem)">
      <div class="filters" role="group" aria-label="Filtrar por categoria"><button class="chip" aria-pressed="true" data-cat="">${esc(P.all)}</button>${P.categories.map(c => `<button class="chip" aria-pressed="false" data-cat="${esc(c)}">${esc(c)}</button>`).join('')}</div>
      <div class="pf-grid" id="pf-grid"></div></section>${ctaBand(C.home.cta.title, C.home.cta.text, C.home.cta.button)}`,
    after(root) {
      const grid = $('#pf-grid', root);
      const draw = cat => {
        const list = P.items.map((it, i) => [it, i]).filter(([it]) => !cat || it.category === cat);
        grid.innerHTML = list.length ? list.map(([it, i]) => pfCard(it, i)).join('') : `<p>${esc(P.empty)}</p>`;
      };
      draw('');
      $$('.chip', root).forEach(b => b.addEventListener('click', () => { $$('.chip', root).forEach(x => x.setAttribute('aria-pressed', x === b)); draw(b.dataset.cat); }));
    }
  };
}

function about() {
  const A = C.about;
  return {
    title: A.title,
    html: `${pageHead(A.title, A.subtitle)}<div class="container"><div class="media r-21-9">${media(A.media, A.title, { eager: true })}</div></div>
      <section class="section"><div class="container split"><h2>${esc(A.storyTitle)}</h2><div class="prose lead" style="max-width:none">${paras(A.story)}</div></div></section>
      ${(A.values || []).length ? `<section class="section alt"><div class="container"><div class="section-head"><h2>${esc(A.valuesTitle)}</h2></div><div class="values">${A.values.map(v => `<div class="value"><h3>${esc(v.title)}</h3><p>${esc(v.text)}</p></div>`).join('')}</div></div></section>` : ''}
      ${(A.timeline || []).length ? `<section class="section"><div class="container split"><h2>${esc(A.timelineTitle)}</h2><div class="timeline">${A.timeline.map(t => `<div class="tl"><b>${esc(t.year)}</b><h3 style="margin:.2rem 0 .3rem">${esc(t.title)}</h3><p>${esc(t.text)}</p></div>`).join('')}</div></div></section>` : ''}
      ${(A.stats || []).length ? `<section class="section alt"><div class="container"><div class="section-head"><h2>${esc(A.statsTitle)}</h2></div><div class="stats">${A.stats.map(s => `<div class="stat"><b>${esc(s.value)}</b><span>${esc(s.label)}</span></div>`).join('')}</div></div></section>` : ''}
      ${(A.team || []).length ? `<section class="section"><div class="container"><div class="section-head"><h2>${esc(A.teamTitle)}</h2></div><div class="team">${A.team.map(m => `<div class="member"><div class="media">${media(m.photo, m.name)}</div><h3>${esc(m.name)}</h3><span>${esc(m.role)}</span></div>`).join('')}</div></div></section>` : ''}
      ${ctaBand(A.cta.title, '', A.cta.button, '/contato')}`
  };
}

function insights() {
  const I = C.insights, posts = sortedPosts();
  return { title: I.title, html: `${pageHead(I.title, I.subtitle)}<section class="container" style="padding-bottom:clamp(4rem,8vw,7rem)">${posts.length ? `<div class="post-grid">${posts.map(postCard).join('')}</div>` : `<p>${esc(I.empty)}</p>`}</section>${ctaBand(C.home.cta.title, C.home.cta.text, C.home.cta.button)}` };
}
function post(slug) {
  const I = C.insights, p = I.posts.find(x => x.slug === slug);
  if (!p) return notFound();
  return {
    title: p.title, desc: p.excerpt,
    html: `<article class="page-head container article"><p><a class="link" href="/insights">${esc(I.back)}</a></p><div class="post-meta" style="margin-top:2rem"><span>${esc(p.category)}</span><time>${esc(fmtDate(p.date))}</time></div><h1 style="font-size:clamp(2.1rem,5vw,3.6rem);margin:.8rem 0 0">${esc(p.title)}</h1></article>
      <div class="container article"><div class="media r-16-9">${media(p.cover, p.title, { eager: true })}</div><div class="prose" style="margin-top:2.5rem;padding-bottom:clamp(3rem,6vw,5rem)">${md(p.body)}</div></div>${ctaBand(C.home.cta.title, C.home.cta.text, C.home.cta.button)}`
  };
}

function jobs() {
  const J = C.jobs, ops = J.openings || [];
  return {
    title: J.title,
    html: `${pageHead(J.title, J.subtitle)}<section class="container" style="padding-bottom:clamp(3rem,6vw,5rem)"><p class="lead">${esc(J.intro)}</p></section>
      <section class="section alt"><div class="container"><div class="section-head"><h2>${esc(J.openingsTitle)}</h2></div>${ops.length ? ops.map(o => `<details class="job"><summary><div><h3>${esc(o.title)}</h3><span>${[o.area, o.type, o.location].filter(Boolean).map(esc).join(' · ')}</span></div>${ICON.chev}</summary><div class="body">${paras(o.description)}</div></details>`).join('') : `<p>${esc(J.noOpenings)}</p>`}</div></section>
      <section class="section"><div class="container split"><div><h2>${esc(J.formTitle)}</h2>${(J.benefits || []).length ? `<h3 style="margin:2rem 0 .8rem">${esc(J.benefitsTitle)}</h3><ul class="ticks">${J.benefits.map(b => `<li>${esc(b)}</li>`).join('')}</ul>` : ''}</div>
        <form class="form" id="job-form" novalidate>
          <div class="row">${field({ name: 'nome', label: 'Nome completo', required: true })}${field({ name: 'email', label: 'E-mail', type: 'email', required: true })}</div>
          <div class="row">${field({ name: 'telefone', label: 'Telefone / WhatsApp', type: 'tel', required: true })}${field({ name: 'area', label: 'Área de interesse', options: [...(J.areas || []), ...ops.map(o => 'Vaga: ' + o.title)], required: true })}</div>
          ${field({ name: 'link', label: 'Link do portfólio ou LinkedIn', type: 'url', placeholder: 'https://' })}
          ${field({ name: 'mensagem', label: 'Conte um pouco sobre você', type: 'textarea' })}${formTail('Enviar perfil')}</form></div></section>`,
    after(root) { bindForm($('#job-form', root), 'job', (d, f) => okMsg(f, J.success)); enableValidation($('#job-form', root)); }
  };
}

function contact() {
  const T = C.contact;
  const info = [
    B.phone && `<li><b>Telefone</b><a href="tel:+${digits(B.phone.length > 11 ? B.phone : '55' + B.phone)}">${esc(B.phone)}</a></li>`,
    B.email && `<li><b>E-mail</b><a href="mailto:${esc(B.email)}">${esc(B.email)}</a></li>`,
    B.address && `<li><b>Endereço</b>${esc(B.address)}</li>`,
    B.hours && `<li><b>Horário</b>${esc(B.hours)}</li>`
  ].filter(Boolean).join('');
  const map = safeUrl(B.mapsEmbed);
  return {
    title: T.title,
    html: `${pageHead(T.title, T.subtitle)}<section class="container" style="padding-bottom:clamp(4rem,8vw,7rem)"><div class="split"><div><ul class="info-list">${info}</ul><p style="margin-top:2rem"><a class="btn ghost" href="${esc(waLink())}" target="_blank" rel="noopener noreferrer">${esc(T.whatsappLabel)}</a></p>${map ? `<div class="media map"><iframe src="${esc(map)}" title="Mapa" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>` : ''}</div>
      <form class="form" id="contact-form" novalidate><h2 style="font-size:1.8rem">${esc(T.formTitle)}</h2>
        <div class="row">${field({ name: 'nome', label: 'Nome', required: true })}${field({ name: 'email', label: 'E-mail', type: 'email', required: true })}</div>
        ${field({ name: 'telefone', label: 'Telefone / WhatsApp', type: 'tel' })}${field({ name: 'mensagem', label: 'Mensagem', type: 'textarea', required: true })}${formTail('Enviar mensagem')}</form></div></section>`,
    after(root) { bindForm($('#contact-form', root), 'contact', (d, f) => okMsg(f, T.success)); enableValidation($('#contact-form', root)); }
  };
}

function quote() {
  const Q = C.quote, qs = new URLSearchParams(location.search);
  const sel = C.solutions.items.find(s => s.slug === qs.get('servico'));
  const pre = qs.get('produto') ? `Tenho interesse no produto: ${qs.get('produto')}.\n` : '';
  return {
    title: Q.title,
    html: `${pageHead(Q.title, Q.subtitle)}<section class="container" style="padding-bottom:clamp(4rem,8vw,7rem)"><div id="quote-box" style="max-width:820px"><form class="form" id="quote-form" novalidate>
      <div class="row">${field({ name: 'nome', label: 'Nome', required: true })}${field({ name: 'empresa', label: 'Empresa' })}</div>
      <div class="row">${field({ name: 'email', label: 'E-mail', type: 'email', required: true })}${field({ name: 'telefone', label: 'Telefone / WhatsApp', type: 'tel', required: true })}</div>
      <div class="row">${field({ name: 'servico', label: 'O que você precisa?', required: true, options: [...C.solutions.items.map(s => s.title), Q.other], value: sel ? sel.title : '' })}${field({ name: 'prazo', label: 'Prazo desejado', options: Q.deadlines })}</div>
      ${field({ name: 'local', label: 'Local e medidas aproximadas', placeholder: 'Ex.: fachada de 6 m × 1,2 m, em Maringá' })}
      ${field({ name: 'mensagem', label: 'Conte sobre o projeto', type: 'textarea', value: pre, rows: 6 })}
      ${field({ name: 'referencias', label: 'Link de referências ou arquivos (Drive, Dropbox…)', type: 'url', placeholder: 'https://' })}${formTail(C.header.cta)}</form></div></section>`,
    after(root) {
      const form = $('#quote-form', root);
      bindForm(form, 'quote', d => {
        const msg = `Olá! Acabei de enviar um pedido de orçamento pelo site.\nNome: ${d.nome}\nServiço: ${d.servico || '-'}${d.empresa ? '\nEmpresa: ' + d.empresa : ''}`;
        $('#quote-box').innerHTML = `<div class="success"><h2>${esc(Q.success)}</h2><p><a class="btn" href="${esc(waLink(msg))}" target="_blank" rel="noopener noreferrer">${esc(Q.successWhatsapp)}</a></p></div>`;
        $('#quote-box').scrollIntoView({ behavior: 'smooth', block: 'center' });
      });
      enableValidation(form);
    }
  };
}

const prodCard = p => `<article class="prod"><div class="media">${p.badge ? `<span class="badge">${esc(p.badge)}</span>` : ''}${media(p.image, p.name)}</div><h3>${esc(p.name)}</h3><p style="margin:0">${esc(p.description)}</p><span class="price">${p.price ? esc(p.price) : ''}</span>${safeUrl(p.paymentLink) ? `<a class="btn" href="${esc(safeUrl(p.paymentLink))}" target="_blank" rel="noopener noreferrer">${esc(C.products.buy)}</a>` : `<a class="btn ghost" href="/orcamento?produto=${encodeURIComponent(p.name)}">${esc(C.products.consult)}</a>`}</article>`;
function products() {
  const P = C.products, list = activeProducts();
  return { title: P.title, html: `${pageHead(P.title, P.subtitle)}<section class="container" style="padding-bottom:clamp(4rem,8vw,7rem)">${list.length ? `<div class="prod-grid">${list.map(prodCard).join('')}</div>` : `<p>${esc(P.empty)}</p>`}</section>` };
}
function privacy() {
  return { title: C.privacy.title, html: `${pageHead(C.privacy.title, '')}<div class="container article"><div class="prose" style="padding-bottom:clamp(4rem,8vw,7rem)">${md(C.privacy.body)}</div></div>` };
}
function notFound() {
  return { title: 'Página não encontrada', html: `${pageHead('Página não encontrada', 'O endereço que você acessou não existe ou foi movido.')}<div class="container" style="padding-bottom:6rem"><a class="btn" href="/">Voltar ao início</a></div>` };
}

/* validação amigável (mensagens em português) */
function enableValidation(form) {
  form.addEventListener('invalid', e => {
    const el = e.target; el.setCustomValidity('');
    if (el.validity.valueMissing) el.setCustomValidity(el.type === 'checkbox' ? 'Marque para continuar.' : 'Preencha este campo.');
    else if (el.validity.typeMismatch) el.setCustomValidity('Confira o formato informado.');
  }, true);
  form.addEventListener('input', e => e.target.setCustomValidity && e.target.setCustomValidity(''));
  form.noValidate = false;
}

/* ---------- lightbox do portfólio ---------- */
function openProject(i) {
  const it = C.portfolio.items[i]; if (!it) return;
  const dlg = $('#lightbox');
  const rows = [['Cliente', it.client], ['Categoria', it.category], ['Ano', it.year]].filter(r => r[1]);
  dlg.innerHTML = `<div class="lb"><div class="media">${media(it.video || it.image, it.title, { controls: true, eager: true })}</div>
    <div class="lb-info"><h2 style="font-size:1.8rem">${esc(it.title)}</h2><p>${esc(it.description)}</p><dl>${rows.map(r => `<dt>${r[0]}</dt><dd>${esc(r[1])}</dd>`).join('')}</dl><p style="margin-top:1.2rem"><a class="btn" href="/orcamento">${esc(C.solutions.cta)}</a></p></div></div>
    <button class="lb-close" aria-label="Fechar">${ICON.close}</button>`;
  dlg.showModal();
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-pf]'); if (b) return openProject(+b.dataset.pf);
  const dlg = $('#lightbox');
  if (e.target === dlg || e.target.closest('.lb-close') || (dlg.open && e.target.closest('.lb-info a'))) dlg.close();
});
$('#lightbox').addEventListener('close', () => { $('#lightbox').innerHTML = ''; });

/* ---------- cookies e rastreamento (LGPD) ---------- */
const CK = 'letter_consent';
function readConsent() {
  const m = document.cookie.split('; ').find(c => c.startsWith(CK + '='));
  if (!m) return null; const v = m.split('=')[1] || '';
  return { a: /a1/.test(v), m: /m1/.test(v) };
}
function writeConsent(a, m) {
  document.cookie = `${CK}=v1a${+a}m${+m}; Max-Age=${180 * 86400}; Path=/; SameSite=Lax${location.protocol === 'https:' ? '; Secure' : ''}`;
}
let consent = readConsent() || { a: false, m: false };
const loaded = {};
function loadTrackers() {
  const ck = C.cookies;
  if (consent.a && /^G-[A-Z0-9]{4,}$/.test(ck.gaId || '') && !loaded.ga) {
    loaded.ga = 1;
    const s = document.createElement('script'); s.async = true; s.src = 'https://www.googletagmanager.com/gtag/js?id=' + ck.gaId; document.head.appendChild(s);
    window.dataLayer = window.dataLayer || []; window.gtag = function () { dataLayer.push(arguments); };
    gtag('js', new Date()); gtag('config', ck.gaId, { anonymize_ip: true, send_page_view: false });
  }
  if (consent.m && /^\d{5,20}$/.test(ck.pixelId || '') && !loaded.px) {
    loaded.px = 1;
    !function (f, b, e, v, n, t, s) { if (f.fbq) return; n = f.fbq = function () { n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments); }; if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = '2.0'; n.queue = []; t = b.createElement(e); t.async = !0; t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s); }(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', ck.pixelId);
  }
}
function trackPage() {
  if (window.gtag && consent.a) gtag('event', 'page_view', { page_path: location.pathname, page_title: document.title });
  if (window.fbq && consent.m) fbq('track', 'PageView');
}
function cookieBanner(force) {
  const ck = C.cookies, box = $('#cookies');
  if (!force && readConsent()) return;
  let custom = !!force;
  const draw = () => {
    box.innerHTML = `<div class="cookie" role="dialog" aria-label="${esc(ck.title)}"><h3>${esc(ck.title)}</h3><p>${esc(ck.text)} <a href="/privacidade" style="text-decoration:underline">${esc(C.privacy.title)}</a></p>
      ${custom ? `<div class="prefs"><label><input type="checkbox" checked disabled> <span>Essenciais<small>Necessários para o site funcionar e para a segurança.</small></span></label>
      <label><input type="checkbox" id="ck-a" ${consent.a ? 'checked' : ''}> <span>Análise<small>Estatísticas de acesso para melhorarmos o site.</small></span></label>
      <label><input type="checkbox" id="ck-m" ${consent.m ? 'checked' : ''}> <span>Marketing<small>Mede a eficácia dos nossos anúncios.</small></span></label></div>
      <div class="acts"><button class="btn sm" id="ck-save">${esc(ck.save)}</button></div>`
      : `<div class="acts"><button class="btn sm" id="ck-all">${esc(ck.accept)}</button><button class="btn sm ghost" id="ck-none">${esc(ck.reject)}</button><button class="btn sm ghost" id="ck-cust">${esc(ck.customize)}</button></div>`}</div>`;
    const set = (a, m) => {
      const had = consent; writeConsent(a, m); consent = { a, m }; box.innerHTML = '';
      if ((had.a && !a) || (had.m && !m)) return location.reload();
      loadTrackers(); trackPage();
    };
    if (custom) $('#ck-save').onclick = () => set($('#ck-a').checked, $('#ck-m').checked);
    else { $('#ck-all').onclick = () => set(true, true); $('#ck-none').onclick = () => set(false, false); $('#ck-cust').onclick = () => { custom = true; draw(); }; }
  };
  draw();
}

/* ---------- roteador ---------- */
function route(path) {
  const seg = path.split('/').filter(Boolean);
  if (!seg.length) return home();
  if (seg[0] === 'insights' && seg[1] && seg.length === 2) return post(decodeURIComponent(seg[1]));
  if (seg.length > 1) return notFound();
  return ({ solucoes: solutions, portfolio, sobre: about, insights, 'trabalhe-conosco': jobs, contato: contact, orcamento: quote, produtos: products, privacidade: privacy }[seg[0]] || notFound)();
}
function render() {
  const path = location.pathname.replace(/\/+$/, '') || '/';
  const page = route(path), main = $('#main');
  main.innerHTML = page.html;
  document.title = page.title ? `${page.title} · ${B.name}` : C.seo.title;
  const d = $('meta[name=description]'); if (d) d.content = page.desc || C.seo.description;
  $('#footer').classList.toggle('after-cta', !!(main.lastElementChild && main.lastElementChild.classList.contains('cta-band')));
  $$('#header .nav a').forEach(a => { a.removeAttribute('aria-current'); if (a.getAttribute('href') === path || (a.getAttribute('href') !== '/' && path.startsWith(a.getAttribute('href') + '/'))) a.setAttribute('aria-current', 'page'); });
  page.after && page.after(main);
  if (!location.hash) scrollTo(0, 0);
  trackPage();
}
function go(url) { history.pushState({}, '', url); render(); $('#main').focus({ preventScroll: true }); }
document.addEventListener('click', e => {
  const a = e.target.closest('a[href]');
  if (!a || e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || a.target || a.hasAttribute('download')) return;
  const h = a.getAttribute('href');
  if (h.startsWith('/') && !h.startsWith('//') && !/^\/(admin|uploads|api)(\/|$)/.test(h)) { e.preventDefault(); go(h); }
});
addEventListener('popstate', render);

renderChrome();
loadTrackers();
render();
cookieBanner();
})();
