/* Letter — painel administrativo (sem dependências) */
(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Math.random().toString(36).slice(2, 9);
const clone = o => JSON.parse(JSON.stringify(o));
const get = (o, path) => path.split('.').reduce((a, k) => (a == null ? a : a[k]), o);
function set(o, path, val) {
  const ks = path.split('.'); let c = o;
  for (let i = 0; i < ks.length - 1; i++) c = c[ks[i]] ??= {};
  c[ks[ks.length - 1]] = val;
}
async function api(path, opts = {}) {
  const r = await fetch(path, { ...opts, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'letter', ...(opts.headers || {}) } });
  let j = null; try { j = await r.json(); } catch {}
  if (!r.ok) throw new Error((j && j.error) || 'Erro (' + r.status + ')');
  return j;
}
function toast(msg, isErr) {
  const t = $('#toast'); t.textContent = msg; t.className = isErr ? 'err' : '';
  requestAnimationFrame(() => t.classList.add('show'));
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 3200);
}

/* ---------- estado ---------- */
let CONTENT = null, ORIGINAL = null, DIRTY = false;
const app = $('#app');
const markDirty = () => { DIRTY = true; const d = $('.dot'); if (d) d.classList.add('dirty'); };
const markClean = () => { DIRTY = false; const d = $('.dot'); if (d) d.classList.remove('dirty'); };
addEventListener('beforeunload', e => { if (DIRTY) { e.preventDefault(); e.returnValue = ''; } });

/* ---------- login ---------- */
async function boot() {
  let me; try { me = await api('/api/me'); } catch { me = { auth: false }; }
  if (!me.auth) return renderLogin();
  CONTENT = await api('/api/content'); ORIGINAL = clone(CONTENT);
  renderShell(me.mustChange);
}
function renderLogin() {
  app.innerHTML = `<div class="login-wrap"><form class="login-box" id="login-form">
    <img src="/assets/logo.svg" alt="Letter">
    <h1>Painel administrativo</h1>
    <p class="hint">Entre com a senha de acesso para editar o site.</p>
    <div class="f"><label for="pw">Senha</label><input id="pw" type="password" autocomplete="current-password" required autofocus></div>
    <div class="f" id="login-err" style="display:none;color:#b3261e;font-size:.85rem"></div>
    <button class="btn" style="width:100%;justify-content:center" type="submit">Entrar</button>
  </form></div>`;
  $('#login-form').addEventListener('submit', async e => {
    e.preventDefault();
    const err = $('#login-err'); err.style.display = 'none';
    try {
      const r = await api('/api/login', { method: 'POST', body: JSON.stringify({ password: $('#pw').value }) });
      CONTENT = await api('/api/content'); ORIGINAL = clone(CONTENT);
      renderShell(r.mustChange);
    } catch (e2) { err.textContent = e2.message; err.style.display = ''; }
  });
}

/* ---------- shell ---------- */
const SECTIONS = [
  { grp: 'Site' },
  { id: 'geral', label: 'Marca e identidade', icon: 'brand' },
  { id: 'menu', label: 'Menu e cabeçalho', icon: 'menu' },
  { id: 'home', label: 'Início', icon: 'home' },
  { id: 'solucoes', label: 'Soluções', icon: 'grid' },
  { id: 'portfolio', label: 'Portfólio', icon: 'grid' },
  { id: 'sobre', label: 'Nossa história', icon: 'doc' },
  { id: 'insights', label: 'Insights', icon: 'doc' },
  { id: 'produtos', label: 'Produtos', icon: 'tag' },
  { id: 'vagas', label: 'Trabalhe conosco', icon: 'doc' },
  { id: 'contato', label: 'Contato', icon: 'doc' },
  { id: 'orcamento', label: 'Orçamento', icon: 'doc' },
  { id: 'privacidade', label: 'Privacidade', icon: 'doc' },
  { grp: 'Gestão' },
  { id: 'midia', label: 'Biblioteca de mídia', icon: 'img' },
  { id: 'mensagens', label: 'Mensagens recebidas', icon: 'mail' },
  { id: 'cookies', label: 'Cookies e rastreamento', icon: 'shield' },
  { id: 'conta', label: 'Conta e segurança', icon: 'lock' }
];
function renderShell(mustChange) {
  app.innerHTML = `<div class="shell">
    <aside class="side" id="side">
      <div class="brand"><img src="/assets/logo.svg" alt=""><b>Painel Letter</b></div>
      <nav id="side-nav"></nav>
      <div class="foot">
        <a class="viewlink" href="/" target="_blank" rel="noopener">Ver site publicado ↗</a>
        <button id="logout">Sair</button>
      </div>
    </aside>
    <div class="main">
      <div class="topbar">
        <div style="display:flex;align-items:center;gap:.7rem">
          <button class="menu-toggle" id="menu-toggle" aria-label="Menu">☰</button>
          <h2 id="topbar-title">Marca e identidade</h2>
        </div>
        <div class="status">
          <span class="dot" id="dirty-dot"></span><span id="dirty-label">Tudo salvo</span>
          <button class="btn ghost sm" id="discard">Descartar</button>
          <button class="btn sm" id="save">Salvar alterações</button>
        </div>
      </div>
      <div class="content" id="section"></div>
    </div>
  </div><div id="toast"></div>`;
  const nav = $('#side-nav');
  nav.innerHTML = SECTIONS.map(s => s.grp ? `<div class="grp">${esc(s.grp)}</div>` : `<button data-s="${s.id}">${esc(s.label)}</button>`).join('');
  nav.addEventListener('click', e => { const b = e.target.closest('button[data-s]'); if (b) goSection(b.dataset.s); });
  $('#menu-toggle').addEventListener('click', () => $('#side').classList.toggle('open'));
  $('#logout').addEventListener('click', async () => { if (DIRTY && !confirm('Existem alterações não salvas. Sair mesmo assim?')) return; await api('/api/logout', { method: 'POST' }); location.reload(); });
  $('#save').addEventListener('click', saveAll);
  $('#discard').addEventListener('click', () => { if (!confirm('Descartar alterações não salvas desta sessão?')) return; CONTENT = clone(ORIGINAL); markClean(); goSection(currentSection, true); toast('Alterações descartadas.'); });
  goSection(mustChange ? 'conta' : 'geral');
  if (mustChange) setTimeout(() => toast('Defina uma nova senha para continuar.'), 300);
}
let currentSection = 'geral';
function goSection(id, force) {
  if (!force && id === currentSection && $('#section').children.length) {}
  currentSection = id;
  $$('#side-nav button').forEach(b => b.classList.toggle('on', b.dataset.s === id));
  $('#side').classList.remove('open');
  const meta = SECTIONS.find(s => s.id === id);
  $('#topbar-title').textContent = meta ? meta.label : '';
  const fn = RENDERERS[id]; const sec = $('#section');
  sec.innerHTML = ''; if (fn) fn(sec);
}
async function saveAll() {
  const btn = $('#save'); btn.disabled = true; btn.textContent = 'Salvando…';
  try {
    await api('/api/content', { method: 'PUT', body: JSON.stringify(CONTENT) });
    ORIGINAL = clone(CONTENT); markClean(); $('#dirty-label').textContent = 'Tudo salvo';
    toast('Alterações publicadas no site.');
  } catch (e) { toast(e.message, true); }
  finally { btn.disabled = false; btn.textContent = 'Salvar alterações'; }
}
function onEdit() { markDirty(); $('#dirty-label').textContent = 'Alterações não salvas'; }

/* ---------- construtores de campo ---------- */
function field(label, input, help) {
  const w = document.createElement('div'); w.className = 'f';
  const l = document.createElement('label'); l.textContent = label; w.appendChild(l);
  w.appendChild(input);
  if (help) { const h = document.createElement('div'); h.className = 'help'; h.textContent = help; w.appendChild(h); }
  return w;
}
function textInput(path, opts = {}) {
  const el = document.createElement(opts.area ? 'textarea' : 'input');
  if (!opts.area) el.type = opts.type || 'text';
  el.value = get(CONTENT, path) ?? '';
  if (opts.placeholder) el.placeholder = opts.placeholder;
  el.addEventListener('input', () => { set(CONTENT, path, el.value); onEdit(); });
  return el;
}
function selectInput(path, options) {
  const el = document.createElement('select');
  el.innerHTML = options.map(o => `<option value="${esc(o)}">${esc(o)}</option>`).join('');
  el.value = get(CONTENT, path) ?? options[0];
  el.addEventListener('change', () => { set(CONTENT, path, el.value); onEdit(); });
  return el;
}
function checkField(label, path) {
  const w = document.createElement('div'); w.className = 'f check';
  const el = document.createElement('input'); el.type = 'checkbox'; el.id = 'c-' + uid();
  el.checked = !!get(CONTENT, path);
  el.addEventListener('change', () => { set(CONTENT, path, el.checked); onEdit(); });
  const l = document.createElement('label'); l.htmlFor = el.id; l.textContent = label;
  w.append(el, l); return w;
}
function colorField(label, path) {
  const wrap = document.createElement('div');
  const row = document.createElement('div'); row.className = 'colorf';
  const c = document.createElement('input'); c.type = 'color'; c.value = /^#[0-9a-f]{6}$/i.test(get(CONTENT, path)) ? get(CONTENT, path) : '#000000';
  const t = document.createElement('input'); t.type = 'text'; t.value = get(CONTENT, path) ?? '';
  c.addEventListener('input', () => { t.value = c.value; set(CONTENT, path, c.value); onEdit(); });
  t.addEventListener('input', () => { set(CONTENT, path, t.value); if (/^#[0-9a-f]{6}$/i.test(t.value)) c.value = t.value; onEdit(); });
  row.append(c, t); wrap.appendChild(row);
  return field(label, wrap);
}

/* ---------- seletor de mídia ---------- */
function isVideo(u) { return /\.(mp4|webm)(\?|$)/i.test(u || ''); }
function mediaPreview(url) {
  if (!url) return `<span>Sem mídia selecionada</span>`;
  if (isVideo(url)) return `<video src="${esc(url)}" muted></video>`;
  if (/youtu\.be|youtube\.com|vimeo\.com/.test(url)) return `<span>Vídeo incorporado (${esc(url)})</span>`;
  return `<img src="${esc(url)}" alt="">`;
}
function mediaField(label, path, help) {
  const wrap = document.createElement('div'); wrap.className = 'mediaf';
  const url = get(CONTENT, path) || '';
  wrap.innerHTML = `<div class="prev">${mediaPreview(url)}</div>
    <div class="row"><input type="text" placeholder="Cole uma URL (imagem, .mp4 ou link do YouTube/Vimeo)" value="${esc(url)}">
    <label class="btn ghost sm" style="cursor:pointer">Enviar arquivo<input type="file" accept="image/*,video/mp4,video/webm" hidden></label></div>`;
  const input = $('input[type=text]', wrap), file = $('input[type=file]', wrap), prev = $('.prev', wrap);
  const apply = v => { set(CONTENT, path, v); prev.innerHTML = mediaPreview(v); onEdit(); };
  input.addEventListener('input', () => apply(input.value));
  file.addEventListener('change', async () => {
    const f = file.files[0]; if (!f) return;
    prev.innerHTML = '<span>Enviando…</span>';
    try {
      const url2 = await uploadFile(f);
      input.value = url2; apply(url2); toast('Arquivo enviado.');
    } catch (e) { toast(e.message, true); prev.innerHTML = mediaPreview(input.value); }
  });
  return field(label, wrap, help);
}
async function uploadFile(f) {
  if (f.size > 200 * 1024 * 1024) throw new Error('Arquivo maior que 200 MB.');
  const r = await fetch('/api/upload?name=' + encodeURIComponent(f.name), { method: 'POST', headers: { 'X-Requested-With': 'letter', 'Content-Type': 'application/octet-stream' }, body: f });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'Falha no envio.');
  return j.url;
}

/* ---------- editor de listas repetíveis ---------- */
// spec: [{key,label,type:'text'|'textarea'|'media'|'tags'|'url'|'select',options}]
function arrayEditor(path, spec, opts = {}) {
  const wrap = document.createElement('div');
  const listWrap = document.createElement('div');
  const draw = () => {
    listWrap.innerHTML = '';
    const arr = get(CONTENT, path) || [];
    arr.forEach((item, i) => {
      const box = document.createElement('div'); box.className = 'arr-item';
      const head = document.createElement('div'); head.className = 'arr-head';
      head.innerHTML = `<b>${esc(opts.itemLabel ? opts.itemLabel(item, i) : `Item ${i + 1}`)}</b>`;
      const acts = document.createElement('div'); acts.className = 'arr-acts';
      const mk = (title, svg, fn) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'icon-btn'; b.title = title; b.innerHTML = svg; b.addEventListener('click', fn); return b; };
      if (i > 0) acts.appendChild(mk('Mover para cima', '↑', () => { [arr[i - 1], arr[i]] = [arr[i], arr[i - 1]]; onEdit(); draw(); }));
      if (i < arr.length - 1) acts.appendChild(mk('Mover para baixo', '↓', () => { [arr[i + 1], arr[i]] = [arr[i], arr[i + 1]]; onEdit(); draw(); }));
      const del = mk('Remover', '✕', () => { if (confirm('Remover este item?')) { arr.splice(i, 1); onEdit(); draw(); } });
      del.classList.add('danger'); acts.appendChild(del);
      head.appendChild(acts); box.appendChild(head);
      spec.forEach(s => {
        const p = `${path}.${i}.${s.key}`;
        if (s.type === 'media') box.appendChild(mediaField(s.label, p));
        else if (s.type === 'textarea') box.appendChild(field(s.label, textInput(p, { area: true })));
        else if (s.type === 'select') box.appendChild(field(s.label, selectInput(p, s.options)));
        else if (s.type === 'tags') box.appendChild(tagsField(s.label, p));
        else if (s.type === 'check') box.appendChild(checkField(s.label, p));
        else box.appendChild(field(s.label, textInput(p, { type: s.type === 'url' ? 'url' : 'text', placeholder: s.placeholder })));
      });
      listWrap.appendChild(box);
    });
    if (!arr.length) listWrap.innerHTML = '<p class="empty">Nenhum item ainda.</p>';
  };
  draw();
  const addBtn = document.createElement('button'); addBtn.type = 'button'; addBtn.className = 'btn ghost sm add-row';
  addBtn.textContent = opts.addLabel || '+ Adicionar item';
  addBtn.addEventListener('click', () => { const arr = get(CONTENT, path) || []; set(CONTENT, path, arr); arr.push(clone(opts.blank || {})); onEdit(); draw(); });
  wrap.append(listWrap, addBtn);
  return wrap;
}
function tagsField(label, path) {
  const wrap = document.createElement('div'); wrap.className = 'tag-input';
  const chips = document.createElement('div'); chips.className = 'chips';
  const inp = document.createElement('input'); inp.type = 'text'; inp.placeholder = 'Digite e pressione Enter';
  const draw = () => {
    const arr = get(CONTENT, path) || [];
    chips.innerHTML = arr.map((t, i) => `<span class="chip">${esc(t)}<button type="button" data-i="${i}">✕</button></span>`).join('');
  };
  draw();
  chips.addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; const arr = get(CONTENT, path); arr.splice(+b.dataset.i, 1); onEdit(); draw(); });
  inp.addEventListener('keydown', e => {
    if (e.key === 'Enter' && inp.value.trim()) { e.preventDefault(); const arr = get(CONTENT, path) || []; set(CONTENT, path, arr); arr.push(inp.value.trim()); inp.value = ''; onEdit(); draw(); }
  });
  wrap.append(chips, inp);
  return field(label, wrap);
}
function card(title, sub) {
  const c = document.createElement('div'); c.className = 'card';
  if (title) c.innerHTML = `<h3>${esc(title)}</h3>${sub ? `<p class="sub">${esc(sub)}</p>` : ''}`;
  return c;
}
function grid(n, ...els) { const g = document.createElement('div'); g.className = n === 3 ? 'grid3' : 'grid2'; els.forEach(e => g.appendChild(e)); return g; }

/* ---------- seções ---------- */
const RENDERERS = {
  geral(sec) {
    const c1 = card('Identidade da marca', 'Nome, logotipo e canais de contato.');
    c1.appendChild(grid(2, field('Nome da marca', textInput('brand.name')), field('Descritor (ex.: Comunicação Visual)', textInput('brand.descriptor'))));
    c1.appendChild(mediaField('Logotipo (fundo claro)', 'brand.logo', 'Se vazio, usa o logotipo padrão da Letter.'));
    c1.appendChild(mediaField('Logotipo (versão para rodapé escuro, opcional)', 'brand.logoLight'));
    c1.appendChild(mediaField('Ícone do site (favicon)', 'brand.favicon'));
    sec.appendChild(c1);

    const c2 = card('Contato e redes sociais');
    c2.appendChild(grid(2, field('WhatsApp (DDI+DDD+número, só dígitos)', textInput('brand.whatsapp', { placeholder: '5544999999999' })), field('Telefone exibido no site', textInput('brand.phone'))));
    c2.appendChild(field('Mensagem padrão do botão de WhatsApp', textInput('brand.whatsappMessage', { area: true })));
    c2.appendChild(grid(2, field('E-mail', textInput('brand.email', { type: 'email' })), field('Endereço', textInput('brand.address'))));
    c2.appendChild(field('Horário de atendimento', textInput('brand.hours')));
    c2.appendChild(grid(2, field('Instagram (URL)', textInput('brand.instagram', { type: 'url' })), field('Facebook (URL)', textInput('brand.facebook', { type: 'url' }))));
    c2.appendChild(grid(2, field('LinkedIn (URL)', textInput('brand.linkedin', { type: 'url' })), field('YouTube (URL)', textInput('brand.youtube', { type: 'url' }))));
    c2.appendChild(field('Mapa incorporado (URL de embed do Google Maps)', textInput('brand.mapsEmbed', { type: 'url' }), 'No Google Maps: Compartilhar → Incorporar um mapa → copie apenas o link do src.'));
    sec.appendChild(c2);

    const c3 = card('Cores', 'Seguem o manual de marca da Letter — altere apenas se necessário.');
    c3.appendChild(grid(3, colorField('Cor principal (títulos)', 'theme.colors.ink'), colorField('Cor de destaque (botões)', 'theme.colors.brand'), colorField('Cor de texto', 'theme.colors.text')));
    c3.appendChild(grid(3, colorField('Linhas e bordas', 'theme.colors.line'), colorField('Cor de apoio', 'theme.colors.accent'), colorField('Superfície (fundos alternados)', 'theme.colors.surface')));
    sec.appendChild(c3);

    const c4 = card('Tipografia e forma');
    c4.appendChild(grid(2, field('Fonte de títulos (Google Fonts)', textInput('theme.fonts.heading')), field('Fonte de texto (Google Fonts)', textInput('theme.fonts.body'))));
    c4.appendChild(grid(2, field('Peso dos títulos (300–800)', textInput('theme.headingWeight', { type: 'number' })), field('Arredondamento dos cantos (px)', textInput('theme.radius', { type: 'number' }))));
    sec.appendChild(c4);

    const c5 = card('SEO', 'Como o site aparece no Google e ao compartilhar links.');
    c5.appendChild(field('Título padrão', textInput('seo.title')));
    c5.appendChild(field('Descrição padrão', textInput('seo.description', { area: true })));
    c5.appendChild(mediaField('Imagem de compartilhamento (Open Graph)', 'seo.ogImage'));
    sec.appendChild(c5);
  },

  menu(sec) {
    const c = card('Itens do menu', 'Controle o rótulo e a visibilidade de cada item. A ordem aqui é a ordem no site.');
    c.appendChild(arrayEditor('nav', [
      { key: 'label', label: 'Rótulo' }, { key: 'path', label: 'Endereço (ex.: /solucoes)' }, { key: 'visible', label: 'Visível no menu', type: 'check' }
    ], { itemLabel: it => it.label || 'Item', blank: { label: 'Novo item', path: '/', visible: true } }));
    sec.appendChild(c);
    const c2 = card('Botão do cabeçalho');
    c2.appendChild(field('Texto do botão "Solicitar Orçamento"', textInput('header.cta')));
    sec.appendChild(c2);
    const c3 = card('Rodapé');
    c3.appendChild(field('Texto sobre a empresa', textInput('footer.text', { area: true })));
    c3.appendChild(field('Linha de direitos autorais', textInput('footer.copyright')));
    sec.appendChild(c3);
  },

  home(sec) {
    const c = card('Topo (hero)');
    c.appendChild(field('Título principal', textInput('home.hero.title', { area: true })));
    c.appendChild(field('Subtítulo', textInput('home.hero.subtitle', { area: true })));
    c.appendChild(grid(2, field('Texto do botão principal', textInput('home.hero.cta1')), field('Texto do botão secundário', textInput('home.hero.cta2'))));
    c.appendChild(mediaField('Imagem ou vídeo de destaque', 'home.hero.media'));
    sec.appendChild(c);

    const c2 = card('Frase de abertura');
    c2.appendChild(field('Texto', textInput('home.intro.text', { area: true })));
    sec.appendChild(c2);

    const c3 = card('Seções da página inicial');
    c3.appendChild(grid(2, field('Título — Soluções', textInput('home.solutionsTitle')), field('Link — Soluções', textInput('home.solutionsLink'))));
    c3.appendChild(grid(2, field('Título — Portfólio', textInput('home.portfolioTitle')), field('Link — Portfólio', textInput('home.portfolioLink'))));
    c3.appendChild(field('Quantidade de projetos em destaque', textInput('home.featuredCount', { type: 'number' })));
    c3.appendChild(grid(2, field('Título — Insights', textInput('home.insightsTitle')), field('Link — Insights', textInput('home.insightsLink'))));
    sec.appendChild(c3);

    const c4 = card('Chamada final (CTA)');
    c4.appendChild(field('Título', textInput('home.cta.title')));
    c4.appendChild(field('Texto', textInput('home.cta.text', { area: true })));
    c4.appendChild(field('Texto do botão', textInput('home.cta.button')));
    sec.appendChild(c4);
  },

  solucoes(sec) {
    const c = card('Cabeçalho da página');
    c.appendChild(field('Título', textInput('solutions.title')));
    c.appendChild(field('Subtítulo', textInput('solutions.subtitle', { area: true })));
    c.appendChild(field('Texto do botão de orçamento em cada solução', textInput('solutions.cta')));
    sec.appendChild(c);

    const c2 = card('Soluções oferecidas', 'Cada item vira uma seção na página de Soluções, no índice da Home e no menu.');
    c2.appendChild(arrayEditor('solutions.items', [
      { key: 'title', label: 'Título' },
      { key: 'slug', label: 'Identificador na URL (sem espaços/acentos)' },
      { key: 'short', label: 'Resumo curto (aparece na Home)', type: 'textarea' },
      { key: 'description', label: 'Descrição completa', type: 'textarea' },
      { key: 'image', label: 'Imagem', type: 'media' },
      { key: 'features', label: 'Características (uma por vez)', type: 'tags' }
    ], { itemLabel: it => it.title || 'Solução', addLabel: '+ Adicionar solução', blank: { title: 'Nova solução', slug: 'nova-solucao', short: '', description: '', image: '', features: [] } }));
    sec.appendChild(c2);

    const c3 = card('Como trabalhamos (etapas)');
    c3.appendChild(field('Título da seção', textInput('solutions.processTitle')));
    c3.appendChild(arrayEditor('solutions.process', [{ key: 'title', label: 'Título da etapa' }, { key: 'text', label: 'Descrição', type: 'textarea' }],
      { itemLabel: it => it.title || 'Etapa', addLabel: '+ Adicionar etapa', blank: { title: '', text: '' } }));
    sec.appendChild(c3);

    const c4 = card('Vitrine de produtos nesta página');
    c4.appendChild(grid(2, field('Título', textInput('solutions.productsTitle')), field('Link "ver todos"', textInput('solutions.productsLink'))));
    sec.appendChild(c4);
  },

  portfolio(sec) {
    const c = card('Cabeçalho da página');
    c.appendChild(field('Título', textInput('portfolio.title')));
    c.appendChild(field('Subtítulo', textInput('portfolio.subtitle', { area: true })));
    c.appendChild(tagsField('Categorias para filtro', 'portfolio.categories'));
    sec.appendChild(c);

    const c2 = card('Projetos', 'Cada projeto abre em destaque ao ser clicado, com foto ou vídeo, cliente e descrição.');
    c2.appendChild(arrayEditor('portfolio.items', [
      { key: 'title', label: 'Título do projeto' },
      { key: 'category', label: 'Categoria' },
      { key: 'client', label: 'Cliente' },
      { key: 'year', label: 'Ano' },
      { key: 'image', label: 'Imagem de capa', type: 'media' },
      { key: 'video', label: 'Vídeo (upload .mp4 ou link do YouTube/Vimeo, opcional)', type: 'media' },
      { key: 'description', label: 'Descrição do projeto', type: 'textarea' }
    ], { itemLabel: it => it.title || 'Projeto', addLabel: '+ Adicionar projeto', blank: { title: 'Novo projeto', category: '', client: '', year: String(new Date().getFullYear()), image: '', video: '', description: '' } }));
    sec.appendChild(c2);
  },

  sobre(sec) {
    const c = card('Cabeçalho');
    c.appendChild(field('Título', textInput('about.title')));
    c.appendChild(field('Subtítulo', textInput('about.subtitle', { area: true })));
    c.appendChild(mediaField('Imagem ou vídeo de destaque', 'about.media'));
    sec.appendChild(c);

    const c2 = card('Nossa história');
    c2.appendChild(field('Título da seção', textInput('about.storyTitle')));
    c2.appendChild(field('Texto (separe parágrafos com uma linha em branco)', textInput('about.story', { area: true })));
    sec.appendChild(c2);

    const c3 = card('O que nos guia (valores)');
    c3.appendChild(field('Título da seção', textInput('about.valuesTitle')));
    c3.appendChild(arrayEditor('about.values', [{ key: 'title', label: 'Título' }, { key: 'text', label: 'Descrição', type: 'textarea' }],
      { itemLabel: it => it.title || 'Valor', addLabel: '+ Adicionar valor', blank: { title: '', text: '' } }));
    sec.appendChild(c3);

    const c4 = card('Trajetória (linha do tempo)', 'Deixe vazio para ocultar esta seção.');
    c4.appendChild(field('Título da seção', textInput('about.timelineTitle')));
    c4.appendChild(arrayEditor('about.timeline', [{ key: 'year', label: 'Ano' }, { key: 'title', label: 'Título' }, { key: 'text', label: 'Descrição', type: 'textarea' }],
      { itemLabel: it => it.year || 'Marco', addLabel: '+ Adicionar marco', blank: { year: '', title: '', text: '' } }));
    sec.appendChild(c4);

    const c5 = card('Números', 'Deixe vazio para ocultar esta seção.');
    c5.appendChild(field('Título da seção', textInput('about.statsTitle')));
    c5.appendChild(arrayEditor('about.stats', [{ key: 'value', label: 'Número' }, { key: 'label', label: 'Legenda' }],
      { itemLabel: it => it.value || 'Número', addLabel: '+ Adicionar número', blank: { value: '', label: '' } }));
    sec.appendChild(c5);

    const c6 = card('Equipe', 'Deixe vazio para ocultar esta seção.');
    c6.appendChild(field('Título da seção', textInput('about.teamTitle')));
    c6.appendChild(arrayEditor('about.team', [{ key: 'photo', label: 'Foto', type: 'media' }, { key: 'name', label: 'Nome' }, { key: 'role', label: 'Cargo' }],
      { itemLabel: it => it.name || 'Pessoa', addLabel: '+ Adicionar pessoa', blank: { photo: '', name: '', role: '' } }));
    sec.appendChild(c6);

    const c7 = card('Chamada final');
    c7.appendChild(field('Título', textInput('about.cta.title')));
    c7.appendChild(field('Texto do botão', textInput('about.cta.button')));
    sec.appendChild(c7);
  },

  insights(sec) {
    const c = card('Cabeçalho da página');
    c.appendChild(field('Título', textInput('insights.title')));
    c.appendChild(field('Subtítulo', textInput('insights.subtitle', { area: true })));
    sec.appendChild(c);
    const c2 = card('Artigos', 'O corpo aceita parágrafos, linhas "## Subtítulo" e listas com "- item".');
    c2.appendChild(arrayEditor('insights.posts', [
      { key: 'title', label: 'Título' }, { key: 'slug', label: 'Identificador na URL' }, { key: 'date', label: 'Data (AAAA-MM-DD)' },
      { key: 'category', label: 'Categoria' }, { key: 'cover', label: 'Capa', type: 'media' },
      { key: 'excerpt', label: 'Resumo (aparece nas listagens)', type: 'textarea' }, { key: 'body', label: 'Corpo do artigo', type: 'textarea' }
    ], { itemLabel: it => it.title || 'Artigo', addLabel: '+ Adicionar artigo', blank: { title: 'Novo artigo', slug: 'novo-artigo', date: new Date().toISOString().slice(0, 10), category: '', cover: '', excerpt: '', body: '' } }));
    sec.appendChild(c2);
  },

  produtos(sec) {
    const c = card('Cabeçalho da página');
    c.appendChild(field('Título', textInput('products.title')));
    c.appendChild(field('Subtítulo', textInput('products.subtitle', { area: true })));
    sec.appendChild(c);
    const c2 = card('Produtos', 'Com link de pagamento, o botão leva direto ao checkout; sem link, leva ao formulário de orçamento.');
    c2.appendChild(arrayEditor('products.items', [
      { key: 'name', label: 'Nome' }, { key: 'price', label: 'Preço (ex.: R$ 249,90)' }, { key: 'badge', label: 'Selo (ex.: Mais vendido, opcional)' },
      { key: 'image', label: 'Imagem', type: 'media' }, { key: 'description', label: 'Descrição', type: 'textarea' },
      { key: 'paymentLink', label: 'Link de pagamento (checkout)', type: 'url' }, { key: 'active', label: 'Visível no site', type: 'check' }
    ], { itemLabel: it => it.name || 'Produto', addLabel: '+ Adicionar produto', blank: { name: 'Novo produto', price: '', badge: '', image: '', description: '', paymentLink: '', active: true } }));
    sec.appendChild(c2);
  },

  vagas(sec) {
    const c = card('Cabeçalho da página');
    c.appendChild(field('Título', textInput('jobs.title')));
    c.appendChild(field('Subtítulo', textInput('jobs.subtitle', { area: true })));
    c.appendChild(field('Texto de introdução', textInput('jobs.intro', { area: true })));
    sec.appendChild(c);
    const c2 = card('Benefícios');
    c2.appendChild(field('Título da lista', textInput('jobs.benefitsTitle')));
    c2.appendChild(tagsField('Itens', 'jobs.benefits'));
    sec.appendChild(c2);
    const c3 = card('Vagas abertas', 'Deixe vazio para mostrar a mensagem de banco de talentos.');
    c3.appendChild(arrayEditor('jobs.openings', [
      { key: 'title', label: 'Cargo' }, { key: 'area', label: 'Área' }, { key: 'type', label: 'Tipo (ex.: CLT, estágio)' }, { key: 'location', label: 'Local' },
      { key: 'description', label: 'Descrição da vaga', type: 'textarea' }
    ], { itemLabel: it => it.title || 'Vaga', addLabel: '+ Adicionar vaga', blank: { title: '', area: '', type: '', location: '', description: '' } }));
    sec.appendChild(c3);
    const c4 = card('Formulário e áreas de interesse');
    c4.appendChild(tagsField('Áreas de interesse (formulário geral)', 'jobs.areas'));
    c4.appendChild(field('Mensagem de sucesso ao enviar', textInput('jobs.success', { area: true })));
    sec.appendChild(c4);
  },

  contato(sec) {
    const c = card('Página de contato');
    c.appendChild(field('Título', textInput('contact.title')));
    c.appendChild(field('Subtítulo', textInput('contact.subtitle', { area: true })));
    c.appendChild(field('Texto do botão de WhatsApp', textInput('contact.whatsappLabel')));
    c.appendChild(field('Mensagem de sucesso ao enviar', textInput('contact.success', { area: true })));
    sec.appendChild(c);
    const note = card('');
    note.innerHTML = '<p class="sub" style="margin:0">Telefone, e-mail, endereço, horário e mapa desta página são editados em <b>Marca e identidade</b>.</p>';
    sec.appendChild(note);
  },

  orcamento(sec) {
    const c = card('Formulário de orçamento');
    c.appendChild(field('Título', textInput('quote.title')));
    c.appendChild(field('Subtítulo', textInput('quote.subtitle', { area: true })));
    c.appendChild(field('Opção "outro serviço"', textInput('quote.other')));
    c.appendChild(tagsField('Opções de prazo', 'quote.deadlines'));
    c.appendChild(field('Mensagem de sucesso', textInput('quote.success', { area: true })));
    c.appendChild(field('Texto do botão de WhatsApp pós-envio', textInput('quote.successWhatsapp')));
    sec.appendChild(c);
  },

  privacidade(sec) {
    const c = card('Política de privacidade e cookies', 'Use linhas "## Subtítulo" para criar seções dentro do texto.');
    c.appendChild(field('Título', textInput('privacy.title')));
    c.appendChild(field('Conteúdo', textInput('privacy.body', { area: true })));
    sec.appendChild(c);
  },

  cookies(sec) {
    const c = card('Banner de cookies (LGPD)');
    c.appendChild(field('Título', textInput('cookies.title')));
    c.appendChild(field('Texto', textInput('cookies.text', { area: true })));
    c.appendChild(grid(2, field('Botão aceitar', textInput('cookies.accept')), field('Botão essenciais', textInput('cookies.reject'))));
    c.appendChild(grid(2, field('Botão personalizar', textInput('cookies.customize')), field('Botão salvar preferências', textInput('cookies.save'))));
    sec.appendChild(c);
    const c2 = card('Rastreamento (opcional)', 'Só carregam depois que a visitante aceita os cookies correspondentes.');
    c2.appendChild(field('Google Analytics — ID de mensuração (G-XXXXXXX)', textInput('cookies.gaId')));
    c2.appendChild(field('Meta Pixel — ID do pixel', textInput('cookies.pixelId')));
    sec.appendChild(c2);
  },

  midia(sec) { renderMedia(sec); },
  mensagens(sec) { renderLeads(sec); },
  conta(sec) { renderAccount(sec); }
};

/* ---------- biblioteca de mídia ---------- */
async function renderMedia(sec) {
  const c = card('Biblioteca de mídia', 'Arquivos enviados pelo painel. Envie aqui para reutilizar depois em qualquer campo de imagem/vídeo.');
  const drop = document.createElement('div'); drop.className = 'drop';
  drop.innerHTML = 'Arraste arquivos aqui ou <label style="text-decoration:underline;cursor:pointer">escolha no computador<input type="file" multiple hidden accept="image/*,video/mp4,video/webm,application/pdf"></label>';
  const grid_ = document.createElement('div'); grid_.className = 'lib-grid';
  c.append(drop, grid_); sec.appendChild(c);

  async function refresh() {
    let files = []; try { files = await api('/api/media'); } catch (e) { toast(e.message, true); }
    grid_.innerHTML = files.length ? '' : '<p class="empty">Nenhum arquivo enviado ainda.</p>';
    files.forEach(f => {
      const it = document.createElement('div'); it.className = 'lib-item';
      const th = isVideo(f.url) ? `<video src="${esc(f.url)}" muted></video>` : /\.svg$|\.png$|\.jpe?g$|\.webp$|\.gif$|\.avif$/i.test(f.url) ? `<img src="${esc(f.url)}" alt="">` : 'Arquivo';
      it.innerHTML = `<div class="th">${th}</div><div class="meta"><span title="${esc(f.name)}">${esc(f.name)}</span></div>
        <div class="meta" style="padding-top:0"><button class="btn ghost sm" data-copy="${esc(f.url)}">Copiar link</button><button class="icon-btn danger" data-del="${esc(f.name)}" title="Excluir">✕</button></div>`;
      grid_.appendChild(it);
    });
  }
  grid_.addEventListener('click', async e => {
    const cp = e.target.closest('[data-copy]');
    if (cp) { navigator.clipboard?.writeText(cp.dataset.copy).then(() => toast('Link copiado.')); return; }
    const del = e.target.closest('[data-del]');
    if (del) { if (!confirm('Excluir este arquivo da biblioteca?')) return; try { await api('/api/media/' + encodeURIComponent(del.dataset.del), { method: 'DELETE' }); toast('Arquivo excluído.'); refresh(); } catch (er) { toast(er.message, true); } }
  });
  async function handleFiles(list) {
    for (const f of list) { try { await uploadFile(f); } catch (e) { toast(f.name + ': ' + e.message, true); } }
    toast('Envio concluído.'); refresh();
  }
  $('input[type=file]', drop).addEventListener('change', e => handleFiles(e.target.files));
  ['dragover', 'dragenter'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', e => e.dataTransfer.files.length && handleFiles(e.dataTransfer.files));
  refresh();
}

/* ---------- mensagens (leads) ---------- */
const LEAD_LABELS = { quote: 'Orçamento', contact: 'Contato', job: 'Trabalhe conosco' };
async function renderLeads(sec) {
  const c = card('Mensagens recebidas', 'Enviadas pelos formulários de orçamento, contato e trabalhe conosco.');
  const bar = document.createElement('div'); bar.className = 'btnbar'; bar.style.marginBottom = '1rem';
  bar.innerHTML = `<button class="btn ghost sm" data-f="">Todas</button><button class="btn ghost sm" data-f="quote">Orçamento</button><button class="btn ghost sm" data-f="contact">Contato</button><button class="btn ghost sm" data-f="job">Trabalhe conosco</button>`;
  const tableWrap = document.createElement('div'); tableWrap.style.overflow = 'auto';
  c.append(bar, tableWrap); sec.appendChild(c);
  let all = [], filter = '';
  async function load() { try { all = await api('/api/leads'); } catch (e) { toast(e.message, true); all = []; } draw(); }
  function draw() {
    const rows = all.filter(l => !filter || l.type === filter);
    if (!rows.length) { tableWrap.innerHTML = '<p class="empty">Nenhuma mensagem por aqui ainda.</p>'; return; }
    tableWrap.innerHTML = `<table class="leads"><thead><tr><th>Data</th><th>Tipo</th><th>Dados</th><th>Status</th><th></th></tr></thead><tbody>${rows.map(l => {
      const d = new Date(l.createdAt); const dt = d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
      const data = Object.entries(l.data || {}).map(([k, v]) => `<div><b>${esc(k)}:</b> ${esc(v)}</div>`).join('');
      const st = (l.status || 'novo').replace(' ', '-');
      return `<tr data-id="${l.id}"><td>${dt}</td><td><span class="badge">${esc(LEAD_LABELS[l.type] || l.type)}</span></td><td class="lead-data">${data}</td>
        <td class="lead-status"><select>${['novo', 'em atendimento', 'concluído'].map(s => `<option ${s === l.status ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
        <td><button class="icon-btn danger" data-del title="Excluir">✕</button></td></tr>`;
    }).join('')}</tbody></table>`;
  }
  bar.addEventListener('click', e => { const b = e.target.closest('button[data-f]'); if (!b) return; filter = b.dataset.f; $$('button[data-f]', bar).forEach(x => x.classList.toggle('ghost', x !== b)); draw(); });
  tableWrap.addEventListener('change', async e => {
    const sel = e.target.closest('select'); if (!sel) return;
    const id = sel.closest('tr').dataset.id;
    try { await api('/api/leads/' + id, { method: 'PATCH', body: JSON.stringify({ status: sel.value }) }); toast('Status atualizado.'); } catch (er) { toast(er.message, true); }
  });
  tableWrap.addEventListener('click', async e => {
    const b = e.target.closest('[data-del]'); if (!b) return;
    if (!confirm('Excluir esta mensagem?')) return;
    const id = b.closest('tr').dataset.id;
    try { await api('/api/leads/' + id, { method: 'DELETE' }); toast('Mensagem excluída.'); load(); } catch (er) { toast(er.message, true); }
  });
  load();
}

/* ---------- conta / segurança ---------- */
function renderAccount(sec) {
  const c = card('Alterar senha do painel');
  c.innerHTML += `<div class="f"><label>Senha atual</label><input type="password" id="pw-cur" autocomplete="current-password"></div>
    <div class="f"><label>Nova senha (mínimo 10 caracteres)</label><input type="password" id="pw-new" autocomplete="new-password"></div>
    <div class="f"><label>Confirmar nova senha</label><input type="password" id="pw-new2" autocomplete="new-password"></div>
    <button class="btn" id="pw-save">Salvar nova senha</button>`;
  sec.appendChild(c);
  $('#pw-save', c).addEventListener('click', async () => {
    const cur = $('#pw-cur', c).value, n1 = $('#pw-new', c).value, n2 = $('#pw-new2', c).value;
    if (n1.length < 10) return toast('A nova senha precisa ter ao menos 10 caracteres.', true);
    if (n1 !== n2) return toast('As senhas não conferem.', true);
    try { await api('/api/password', { method: 'POST', body: JSON.stringify({ current: cur, next: n1 }) }); toast('Senha atualizada.'); $('#pw-cur', c).value = $('#pw-new', c).value = $('#pw-new2', c).value = ''; }
    catch (e) { toast(e.message, true); }
  });

  const c2 = card('Versões salvas', 'Guardamos as últimas 20 versões do conteúdo — use para voltar caso algo saia errado.');
  const list = document.createElement('div'); c2.appendChild(list); sec.appendChild(c2);
  (async () => {
    let backups = []; try { backups = await api('/api/backups'); } catch {}
    list.innerHTML = backups.length ? backups.slice(0, 20).map(b => {
      const dt = b.replace('content-', '').replace('.json', '').replace(/-/g, (m, i) => i > 9 ? ':' : '-');
      return `<div style="display:flex;justify-content:space-between;align-items:center;padding:.5rem 0;border-bottom:1px solid var(--line)"><span style="font-size:.85rem;color:var(--text)">${esc(b)}</span><button class="btn ghost sm" data-r="${esc(b)}">Restaurar</button></div>`;
    }).join('') : '<p class="empty">Ainda não há versões salvas.</p>';
    list.addEventListener('click', async e => {
      const b = e.target.closest('[data-r]'); if (!b) return;
      if (!confirm('Restaurar esta versão? As alterações não salvas atuais serão perdidas.')) return;
      try { await api('/api/restore', { method: 'POST', body: JSON.stringify({ name: b.dataset.r }) }); toast('Versão restaurada.'); CONTENT = await api('/api/content'); ORIGINAL = clone(CONTENT); markClean(); goSection(currentSection, true); }
      catch (er) { toast(er.message, true); }
    });
  })();
}

boot();
})();
