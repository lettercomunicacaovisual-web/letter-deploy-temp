# Site Letter Comunicação Visual

Site institucional completo, com painel administrativo próprio, pronto para
substituir o site atual (lettercv.com.br). Construído em HTML, CSS e
JavaScript puros, com um pequeno servidor em Node.js — **sem nenhuma
dependência para instalar** (não usa `npm install`, não depende de banco de
dados externo nem de serviços de terceiros para funcionar).

## O que está incluso

- **Site público** minimalista, seguindo o padrão visual do lettercv.com.br,
  com as páginas: Início, Soluções, Portfólio, Nossa História, Insights,
  Trabalhe Conosco, Contato e Solicitar Orçamento.
- **Painel administrativo** em `/admin`, protegido por senha, para editar:
  textos, imagens e vídeos de cada página, logotipo, cores e fontes,
  produtos com link de pagamento, vagas, artigos do blog, itens do menu,
  mensagens recebidas pelos formulários e configurações de cookies.
- **Botão de WhatsApp** flutuante em todas as páginas.
- **Banner de cookies** (LGPD), com opção de personalizar consentimento e
  campos prontos para conectar Google Analytics e Meta Pixel (opcional).
- **Formulários** de orçamento, contato e trabalhe conosco, que caem
  automaticamente na aba "Mensagens recebidas" do painel.
- Sitemap e robots.txt automáticos, cabeçalhos de segurança, upload de
  imagens e vídeos, e backup automático das últimas 20 versões do conteúdo.

## Como funciona (visão geral)

- `server.js` é o único processo que precisa rodar. Ele serve o site, o
  painel e uma pequena API — tudo com os módulos nativos do Node.js.
- Todo o conteúdo do site (textos, links de imagens, cores, etc.) fica em
  `data/content.json`, criado automaticamente a partir de
  `defaults/content.default.json` na primeira vez que algo é salvo pelo
  painel.
- Os arquivos enviados pelo painel (fotos, vídeos, logotipo) ficam na pasta
  `uploads/`.
- Nada disso precisa de banco de dados: são arquivos JSON simples,
  versionados automaticamente a cada salvamento (pasta `data/backups/`).

## Primeiro acesso ao painel

1. Suba o servidor (veja "Publicar no VPS" abaixo).
2. Na **primeira execução**, o servidor gera uma senha temporária e a
   imprime no terminal/log, assim:
   ```
   PRIMEIRO ACESSO AO PAINEL  (/admin)
   Senha temporária: xxxxxxxxxxxx
   ```
3. Acesse `https://lettercv.com.br/admin`, entre com essa senha e o painel
   vai pedir para você trocá-la por uma definitiva (mínimo 10 caracteres) —
   fica em "Conta e segurança".
4. Se preferir escolher a senha inicial você mesma, defina a variável de
   ambiente `ADMIN_PASSWORD` antes de rodar o servidor pela primeira vez
   (veja o `ecosystem.config.cjs`).

## Editando o conteúdo do site

Tudo é feito pelo painel (`/admin`), sem precisar mexer em código:

- **Marca e identidade** — nome, logotipo, WhatsApp, redes sociais, cores
  (já carregadas com a paleta do manual de marca) e fontes.
- **Menu e cabeçalho** — quais páginas aparecem no menu e em que ordem.
- Uma aba para cada página do site, com os textos e imagens daquela página.
- **Produtos** — cadastre produtos com preço, foto e um link de pagamento
  (Mercado Pago, PagSeguro, Stripe, etc.); sem link, o botão leva ao
  formulário de orçamento.
- **Biblioteca de mídia** — envie fotos e vídeos (arraste e solte) e
  reutilize o link em qualquer campo de imagem depois.
- **Mensagens recebidas** — tudo o que chega pelos formulários do site,
  com status (novo / em atendimento / concluído).
- **Cookies e rastreamento** — textos do banner de cookies e, se quiser,
  os IDs do Google Analytics e/ou Meta Pixel (só carregam se a visitante
  aceitar).

Todas as alterações ficam pendentes até clicar em **Salvar alterações** —
o indicador no topo mostra se há mudanças não salvas.

## Publicar no VPS (Hostinger, mesmo servidor do site atual)

Pressupõe Node.js 18+ e PM2 já instalados no VPS (o mesmo usado para o site
Lovable anterior).

```bash
# 1. Envie esta pasta para o servidor, por exemplo:
scp -r site usuario@SEU_IP:/var/www/lettercv-novo

# 2. No servidor:
cd /var/www/lettercv-novo
node server.js        # rode uma vez manualmente para conferir e pegar a senha inicial
# Ctrl+C depois de confirmar que subiu ("Letter no ar em http://127.0.0.1:3000")

# 3. Suba com PM2 (fica de pé mesmo após reiniciar o servidor)
pm2 start deploy/ecosystem.config.cjs
pm2 save

# 4. Configure o Nginx (arquivo de exemplo em deploy/nginx.conf.example)
sudo cp deploy/nginx.conf.example /etc/nginx/sites-available/lettercv.com.br
sudo ln -s /etc/nginx/sites-available/lettercv.com.br /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# 5. SSL (mesmo fluxo já usado no domínio)
sudo certbot --nginx -d lettercv.com.br -d www.lettercv.com.br
```

Para trocar o site atual por este: aponte o Nginx do domínio
`lettercv.com.br` para a porta deste novo processo (3000, como no exemplo)
em vez do processo antigo, e pare o processo antigo no PM2
(`pm2 stop lettercv`) quando estiver tudo validado.

### Variáveis de ambiente (opcionais)

| Variável | Padrão | Para que serve |
|---|---|---|
| `PORT` | `3000` | Porta em que o servidor escuta |
| `HOST` | `127.0.0.1` | Interface de rede |
| `ADMIN_PASSWORD` | gerada automaticamente | Senha inicial do painel |
| `DATA_DIR` | `./data` | Onde ficam conteúdo e backups |
| `UPLOADS_DIR` | `./uploads` | Onde ficam as mídias enviadas |
| `MAX_UPLOAD_MB` | `200` | Tamanho máximo por arquivo enviado |

## Backup e restauração

Toda vez que o conteúdo é salvo no painel, a versão anterior é guardada em
`data/backups/`. Em **Conta e segurança**, dentro do painel, é possível ver
as últimas 20 versões e restaurar qualquer uma delas com um clique.
Recomendamos, além disso, incluir a pasta `data/` e `uploads/` na rotina de
backup do servidor (a maioria dos planos Hostinger já faz backup do VPS
inteiro).

## Segurança

- Sessão do painel protegida por senha com hash forte (scrypt) e cookies
  `HttpOnly`.
- Limite de tentativas de login (6 por 15 minutos por IP).
- Cabeçalhos de segurança (CSP, HSTS quando em HTTPS, X-Frame-Options etc.).
- Formulários públicos com proteção honeypot e limite de envios por IP.
- Uploads restritos a imagens, vídeos (mp4/webm) e PDF, com limite de
  tamanho.
