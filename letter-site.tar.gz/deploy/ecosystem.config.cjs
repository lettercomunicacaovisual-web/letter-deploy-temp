// PM2 — inicia o site Letter como processo persistente no VPS.
// Uso:  pm2 start deploy/ecosystem.config.cjs
module.exports = {
  apps: [
    {
      name: 'letter-site',
      script: 'server.js',
      cwd: __dirname + '/..',
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_memory_restart: '300M',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
        HOST: '127.0.0.1'
        // ADMIN_PASSWORD: defina apenas na primeira execução, se quiser
        // escolher a senha inicial do painel em vez da gerada automaticamente.
      }
    }
  ]
};
