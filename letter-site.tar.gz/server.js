'use strict';
/**
 * Letter — servidor do site e do painel administrativo.
 * Node.js 18+ · zero dependências (nada para instalar).
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = __dirname;
const PUB = path.join(ROOT, 'public');
const DATA = process.env.DATA_DIR || path.join(ROOT, 'data');
const UPLOADS = process.env.UPLOADS_DIR || path.join(ROOT, 'uploads');
const BACKUPS = path.join(DATA, 'backups');
const DEFAULTS = path.join(ROOT, 'defaults', 'content.default.json');
const PORT = +process.env.PORT || 3000;
const HOST = process.env.HOST || '127.0.0.1';
const TRUST_PROXY = process.env.TRUST_PROXY !== '0';
const SESSION_MS = 8 * 3600 * 1000;
const MAX_JSON = 5 * 1024 * 1024;
const MAX_UPLOAD = (+process.env.MAX_UPLOAD_MB || 200) * 1024 * 1024;

for (const d of [DATA, BACKUPS, UPLOADS]) fs.mkdirSync(d, { recursive: true });

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.avif': 'image/avif', '.gif': 'image/gif', '.ico': 'image/x-icon',
  '.mp4': 'video/mp4', '.webm': 'video/webm', '.pdf': 'application/pdf', '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8', '.woff2': 'font/woff2'
};
const UPLOAD_EXT = new Set(['.jpg', '.jpeg', '.png', '.webp', '.avif', '.gif', '.svg', '.mp4', '.webm', '.pdf']);

/* ---------- utilidades ---------- */
const readJSON = (f, fallback) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return fallback; } };
function writeJSON(f, obj) {
  const tmp = f + '.tmp-' + process.pid;
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2));
  fs.renameSync(tmp, f);
}
const isObj = v => v && typeof v === 'object' && !Array.isArray(v);
function deepMerge(base, over) {
  if (!isObj(base) || !isObj(over)) return over === undefined ? base : over;
  const out = { ...base };
  for (const k of Object.keys(over)) out[k] = isObj(base[k]) && isObj(over[k]) ? deepMerge(base[k], over[k]) : over[k];
  return out;
}
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const slug = s => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

function json(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}
function readBody(req, limit = MAX_JSON) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', c => { size += c.length; if (size > limit) { reject(Object.assign(new Error('too large'), { status: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
async function readJsonBody(req) {
  try { return JSON.parse((await readBody(req)).toString('utf8') || '{}'); }
  catch (e) { throw Object.assign(new Error('JSON inválido'), { status: e.status || 400 }); }
}
const cookiesOf = req => Object.fromEntries((req.headers.cookie || '').split(';').map(c => c.trim().split(/=(.*)/s).slice(0, 2)).filter(p => p[0]));
const clientIP = req => (TRUST_PROXY && (req.headers['x-real-ip'] || (req.headers['x-forwarded-for'] || '').split(',')[0].trim())) || req.socket.remoteAddress || '';
const isHTTPS = req => !!req.socket.encrypted || req.headers['x-forwarded-proto'] === 'https';

/* ---------- limite de tentativas ---------- */
const buckets = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  const b = (buckets.get(key) || []).filter(t => now - t < windowMs);
  if (b.length >= max) { buckets.set(key, b); return true; }
  b.push(now); buckets.set(key, b); return false;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of buckets) if (!v.some(t => now - t < 3600e3)) buckets.delete(k); }, 600e3).unref();

/* ---------- autenticação ---------- */
const AUTH_FILE = path.join(DATA, 'auth.json');
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');
function initAuth() {
  if (fs.existsSync(AUTH_FILE)) return;
  const pw = process.env.ADMIN_PASSWORD || crypto.randomBytes(9).toString('base64url');
  const salt = crypto.randomBytes(16).toString('hex');
  writeJSON(AUTH_FILE, { salt, hash: hashPw(pw, salt), mustChange: true });
  console.log('\n  ┌────────────────────────────────────────────┐');
  console.log('  │  PRIMEIRO ACESSO AO PAINEL  (/admin)       │');
  console.log('  │  Senha temporária: ' + pw.padEnd(24) + '│');
  console.log('  │  Você será solicitada a trocá-la ao entrar. │');
  console.log('  └────────────────────────────────────────────┘\n');
}
initAuth();
const checkPw = pw => {
  const a = readJSON(AUTH_FILE, null); if (!a || typeof pw !== 'string') return false;
  const x = Buffer.from(hashPw(pw, a.salt), 'hex'), y = Buffer.from(a.hash, 'hex');
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
const sessions = new Map();
function getSession(req) {
  const sid = cookiesOf(req).letter_sid; const s = sid && sessions.get(sid);
  if (!s) return null;
  if (s.exp < Date.now()) { sessions.delete(sid); return null; }
  s.exp = Date.now() + SESSION_MS; return s;
}
function startSession(req, res) {
  const sid = crypto.randomBytes(32).toString('hex');
  sessions.set(sid, { exp: Date.now() + SESSION_MS });
  const flags = ['HttpOnly', 'SameSite=Strict', 'Path=/', 'Max-Age=' + SESSION_MS / 1000];
  if (isHTTPS(req)) flags.push('Secure');
  res.setHeader('Set-Cookie', `letter_sid=${sid}; ${flags.join('; ')}`);
}
const needAuth = (req, res) => { if (getSession(req)) return true; json(res, 401, { error: 'Não autenticado.' }); return false; };

/* ---------- conteúdo ---------- */
const CONTENT_FILE = path.join(DATA, 'content.json');
const defaults = () => readJSON(DEFAULTS, {});
const getContent = () => deepMerge(defaults(), readJSON(CONTENT_FILE, {}));
function saveContent(obj) {
  if (fs.existsSync(CONTENT_FILE)) {
    fs.copyFileSync(CONTENT_FILE, path.join(BACKUPS, 'content-' + new Date().toISOString().replace(/[:.]/g, '-') + '.json'));
    const all = fs.readdirSync(BACKUPS).filter(f => f.startsWith('content-')).sort();
    all.slice(0, Math.max(0, all.length - 20)).forEach(f => fs.unlink(path.join(BACKUPS, f), () => {}));
  }
  writeJSON(CONTENT_FILE, obj);
}

/* ---------- leads ---------- */
const LEADS_FILE = path.join(DATA, 'leads.json');
const clip = (v, n = 2000) => String(v ?? '').slice(0, n);

/* ---------- cabeçalhos de segurança ---------- */
const CSP = [
  "default-src 'self'", "img-src 'self' data: https:", "media-src 'self' https:",
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com", "font-src 'self' https://fonts.gstatic.com data:",
  "script-src 'self' https://www.googletagmanager.com https://connect.facebook.net",
  "connect-src 'self' https://*.google-analytics.com https://*.analytics.google.com https://www.googletagmanager.com https://www.facebook.com https://connect.facebook.net",
  "frame-src https://www.youtube-nocookie.com https://player.vimeo.com https://www.google.com",
  "object-src 'none'", "base-uri 'self'", "form-action 'self'", "frame-ancestors 'self'"
].join('; ');
function secure(req, res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy', CSP);
  if (isHTTPS(req)) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
}

/* ---------- arquivos estáticos (com suporte a Range para vídeo) ---------- */
function serveFile(req, res, file, cache) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return notFound(req, res);
    const ext = path.extname(file).toLowerCase();
    const h = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Accept-Ranges': 'bytes', 'Last-Modified': st.mtime.toUTCString(), 'Cache-Control': cache || 'public, max-age=3600' };
    if (ext === '.svg' && file.startsWith(UPLOADS)) h['Content-Security-Policy'] = "default-src 'none'; style-src 'unsafe-inline'; sandbox";
    if (req.headers['if-modified-since'] && new Date(req.headers['if-modified-since']) >= new Date(st.mtime.toUTCString())) { res.writeHead(304, h); return res.end(); }
    let start = 0, end = st.size - 1, code = 200;
    const m = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
    if (m && (m[1] || m[2])) {
      if (m[1] === '') { start = Math.max(0, st.size - +m[2]); } else { start = +m[1]; if (m[2]) end = Math.min(+m[2], end); }
      if (start > end || start >= st.size) { res.writeHead(416, { 'Content-Range': 'bytes */' + st.size }); return res.end(); }
      code = 206; h['Content-Range'] = `bytes ${start}-${end}/${st.size}`;
    }
    h['Content-Length'] = end - start + 1;
    res.writeHead(code, h);
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file, { start, end }).on('error', () => res.destroy()).pipe(res);
  });
}
function safeJoin(base, rel) {
  let p; try { p = decodeURIComponent(rel); } catch { return null; }
  if (p.includes('\0')) return null;
  const f = path.join(base, p);
  return f === base || f.startsWith(base + path.sep) ? f : null;
}
function notFound(req, res) {
  if (/^\/(api|uploads|assets|css|js|admin\/)/.test(req.url)) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Não encontrado'); }
  servePage(req, res, 404);
}

/* ---------- página (SPA) com conteúdo, tema e SEO injetados ---------- */
function themeCss(c) {
  const col = (c.theme && c.theme.colors) || {};
  const ok = v => /^#[0-9a-f]{3,8}$/i.test(v || '');
  const map = { ink: '--ink', brand: '--brand', text: '--text', line: '--line', accent: '--accent', surface: '--surface', bg: '--bg' };
  const vars = Object.entries(map).filter(([k]) => ok(col[k])).map(([k, v]) => `${v}:${col[k]}`);
  const f = (c.theme && c.theme.fonts) || {};
  const fam = n => `"${String(n).replace(/[^\w\s-]/g, '')}",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif`;
  if (f.heading) vars.push('--font-head:' + fam(f.heading));
  if (f.body) vars.push('--font-body:' + fam(f.body));
  if (c.theme && Number.isFinite(+c.theme.radius)) vars.push('--radius:' + Math.max(0, Math.min(40, +c.theme.radius)) + 'px');
  if (c.theme && Number.isFinite(+c.theme.headingWeight)) vars.push('--head-weight:' + Math.max(300, Math.min(800, +c.theme.headingWeight)));
  return `:root{${vars.join(';')}}`;
}
function fontLink(c) {
  const f = (c.theme && c.theme.fonts) || {};
  const fams = [...new Set([f.heading, f.body].filter(Boolean))].map(n => 'family=' + encodeURIComponent(String(n).replace(/[^\w\s-]/g, '')).replace(/%20/g, '+') + ':wght@300;400;500;600;700');
  return fams.length ? `<link rel="stylesheet" href="https://fonts.googleapis.com/css2?${fams.join('&')}&display=swap">` : '';
}
function pageTitle(c, pathname) {
  const seg = '/' + pathname.split('/').filter(Boolean)[0];
  if (pathname === '/') return c.seo.title;
  const item = (c.nav || []).find(n => n.path === seg);
  const names = { '/orcamento': (c.quote || {}).title, '/privacidade': (c.privacy || {}).title, '/produtos': (c.products || {}).title };
  const label = (item && item.label) || names[seg];
  return label ? `${label} · ${c.brand.name}` : c.seo.title;
}
function servePage(req, res, code = 200) {
  const c = getContent();
  const u = new URL(req.url, 'http://x');
  const tpl = fs.readFileSync(path.join(PUB, 'index.html'), 'utf8');
  const fav = c.brand.favicon || '/assets/logo-mark.svg';
  const boot = JSON.stringify(c).replace(/</g, '\\u003c').replace(/[\u2028\u2029]/g, '');
  const head = fontLink(c) + `<style id="theme">${themeCss(c)}</style>`;
  const html = tpl
    .replace(/%%TITLE%%/g, esc(pageTitle(c, u.pathname)))
    .replace(/%%DESC%%/g, esc(c.seo.description))
    .replace('%%OG%%', c.seo.ogImage ? `<meta property="og:image" content="${esc(c.seo.ogImage)}">` : '')
    .replace('%%FAV%%', esc(fav))
    .replace('%%HEAD%%', () => head)
    .replace('%%BOOT%%', () => `<script id="boot" type="application/json">${boot}</script>`);
  res.writeHead(code, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
  res.end(req.method === 'HEAD' ? undefined : html);
}

/* ---------- API ---------- */
async function api(req, res, u) {
  const p = u.pathname, m = req.method;
  const mutating = m !== 'GET' && m !== 'HEAD';
  if (mutating && req.headers['x-requested-with'] !== 'letter') return json(res, 403, { error: 'Requisição inválida.' });

  if (p === '/api/content' && m === 'GET') return json(res, 200, getContent());

  if (p === '/api/me' && m === 'GET') {
    const s = getSession(req);
    return json(res, 200, { auth: !!s, mustChange: !!(s && readJSON(AUTH_FILE, {}).mustChange) });
  }
  if (p === '/api/login' && m === 'POST') {
    const ip = clientIP(req);
    if (limited('login:' + ip, 6, 15 * 60e3)) return json(res, 429, { error: 'Muitas tentativas. Aguarde 15 minutos.' });
    const b = await readJsonBody(req);
    if (!checkPw(b.password)) return json(res, 401, { error: 'Senha incorreta.' });
    startSession(req, res);
    return json(res, 200, { ok: true, mustChange: !!readJSON(AUTH_FILE, {}).mustChange });
  }
  if (p === '/api/logout' && m === 'POST') {
    const sid = cookiesOf(req).letter_sid; if (sid) sessions.delete(sid);
    res.setHeader('Set-Cookie', 'letter_sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');
    return json(res, 200, { ok: true });
  }

  /* público: formulários */
  if (p === '/api/lead' && m === 'POST') {
    if (limited('lead:' + clientIP(req), 8, 3600e3)) return json(res, 429, { error: 'Muitos envios. Tente novamente mais tarde.' });
    const b = await readJsonBody(req);
    if (b.website) return json(res, 200, { ok: true }); // honeypot
    const type = ['quote', 'contact', 'job'].includes(b.type) ? b.type : null;
    const d = isObj(b.data) ? b.data : {};
    const name = clip(d.nome, 120).trim(), email = clip(d.email, 160).trim(), phone = clip(d.telefone, 40).trim();
    if (!type || !name || (!email && !phone)) return json(res, 400, { error: 'Preencha nome e ao menos um contato (e-mail ou telefone).' });
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json(res, 400, { error: 'E-mail inválido.' });
    const clean = {}; Object.keys(d).slice(0, 25).forEach(k => { clean[clip(k, 40)] = clip(d[k]); });
    const leads = readJSON(LEADS_FILE, []);
    if (leads.length >= 5000) leads.pop();
    leads.unshift({ id: crypto.randomBytes(6).toString('hex'), type, status: 'novo', createdAt: new Date().toISOString(), data: clean });
    writeJSON(LEADS_FILE, leads);
    return json(res, 200, { ok: true });
  }

  /* daqui em diante: só com login */
  if (!needAuth(req, res)) return;

  if (p === '/api/content' && m === 'PUT') {
    const b = await readJsonBody(req);
    if (!isObj(b) || !isObj(b.brand) || !isObj(b.theme)) return json(res, 400, { error: 'Conteúdo inválido.' });
    saveContent(b); return json(res, 200, { ok: true });
  }
  if (p === '/api/upload' && m === 'POST') return upload(req, res, u);
  if (p === '/api/media' && m === 'GET') {
    const files = fs.readdirSync(UPLOADS).filter(f => UPLOAD_EXT.has(path.extname(f).toLowerCase())).map(f => {
      const st = fs.statSync(path.join(UPLOADS, f)); return { name: f, url: '/uploads/' + f, size: st.size, mtime: st.mtimeMs };
    }).sort((a, b) => b.mtime - a.mtime);
    return json(res, 200, files);
  }
  let mm;
  if ((mm = /^\/api\/media\/([^/]+)$/.exec(p)) && m === 'DELETE') {
    const f = safeJoin(UPLOADS, mm[1]); if (!f || f === UPLOADS) return json(res, 400, { error: 'Nome inválido.' });
    fs.unlink(f, () => json(res, 200, { ok: true })); return;
  }
  if (p === '/api/leads' && m === 'GET') return json(res, 200, readJSON(LEADS_FILE, []));
  if ((mm = /^\/api\/leads\/([a-f0-9]+)$/.exec(p))) {
    const leads = readJSON(LEADS_FILE, []); const i = leads.findIndex(l => l.id === mm[1]);
    if (i < 0) return json(res, 404, { error: 'Não encontrado.' });
    if (m === 'PATCH') { const b = await readJsonBody(req); if (['novo', 'em atendimento', 'concluído'].includes(b.status)) leads[i].status = b.status; }
    else if (m === 'DELETE') leads.splice(i, 1);
    else return json(res, 405, { error: 'Método não permitido.' });
    writeJSON(LEADS_FILE, leads); return json(res, 200, { ok: true });
  }
  if (p === '/api/password' && m === 'POST') {
    const b = await readJsonBody(req);
    if (!checkPw(b.current)) return json(res, 401, { error: 'Senha atual incorreta.' });
    if (typeof b.next !== 'string' || b.next.length < 10) return json(res, 400, { error: 'A nova senha precisa ter ao menos 10 caracteres.' });
    const salt = crypto.randomBytes(16).toString('hex');
    writeJSON(AUTH_FILE, { salt, hash: hashPw(b.next, salt), mustChange: false });
    sessions.clear(); startSession(req, res);
    return json(res, 200, { ok: true });
  }
  if (p === '/api/backups' && m === 'GET') {
    return json(res, 200, fs.readdirSync(BACKUPS).filter(f => f.startsWith('content-')).sort().reverse());
  }
  if (p === '/api/restore' && m === 'POST') {
    const b = await readJsonBody(req);
    const f = safeJoin(BACKUPS, String(b.name || '')); if (!f || !fs.existsSync(f)) return json(res, 404, { error: 'Versão não encontrada.' });
    saveContent(readJSON(f, {})); return json(res, 200, { ok: true });
  }
  return json(res, 404, { error: 'Rota não encontrada.' });
}

function upload(req, res, u) {
  const orig = u.searchParams.get('name') || 'arquivo';
  const ext = path.extname(orig).toLowerCase();
  if (!UPLOAD_EXT.has(ext)) return json(res, 415, { error: 'Tipo de arquivo não permitido.' });
  if ((+req.headers['content-length'] || 0) > MAX_UPLOAD) return json(res, 413, { error: 'Arquivo muito grande.' });
  const name = `${Date.now().toString(36)}-${slug(path.basename(orig, ext)).slice(0, 40) || 'arquivo'}${ext}`;
  const dest = path.join(UPLOADS, name);
  const ws = fs.createWriteStream(dest);
  let size = 0, aborted = false;
  req.on('data', c => { size += c.length; if (size > MAX_UPLOAD && !aborted) { aborted = true; ws.destroy(); req.destroy(); fs.unlink(dest, () => {}); } });
  req.pipe(ws);
  ws.on('finish', () => { if (!aborted) json(res, 200, { url: '/uploads/' + name, name, size }); });
  ws.on('error', () => { fs.unlink(dest, () => {}); if (!res.headersSent) json(res, 500, { error: 'Falha ao gravar o arquivo.' }); });
}

/* ---------- sitemap / robots ---------- */
function sitemap(req, res) {
  const c = getContent(); const base = (isHTTPS(req) ? 'https://' : 'http://') + req.headers.host;
  const paths = new Set(['/', '/orcamento', '/privacidade', ...(c.nav || []).filter(n => n.visible).map(n => n.path)]);
  (c.insights.posts || []).forEach(p => paths.add('/insights/' + p.slug));
  const xml = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + [...paths].map(p => `<url><loc>${esc(base + p)}</loc></url>`).join('') + '</urlset>';
  res.writeHead(200, { 'Content-Type': MIME['.xml'] }); res.end(xml);
}

/* ---------- servidor ---------- */
const server = http.createServer(async (req, res) => {
  try {
    secure(req, res);
    const u = new URL(req.url, 'http://x');
    const p = u.pathname;
    if (p.startsWith('/api/')) return await api(req, res, u);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    if (p === '/robots.txt') { res.writeHead(200, { 'Content-Type': MIME['.txt'] }); return res.end(`User-agent: *\nDisallow: /admin\nDisallow: /api\nSitemap: ${isHTTPS(req) ? 'https' : 'http'}://${req.headers.host}/sitemap.xml\n`); }
    if (p === '/sitemap.xml') return sitemap(req, res);
    if (p.startsWith('/uploads/')) { const f = safeJoin(UPLOADS, p.slice(9)); return f ? serveFile(req, res, f, 'public, max-age=31536000, immutable') : notFound(req, res); }
    if (p === '/admin' || p === '/admin/') { res.setHeader('X-Robots-Tag', 'noindex'); return serveFile(req, res, path.join(PUB, 'admin', 'index.html'), 'no-cache'); }
    if (p.startsWith('/admin/')) { const f = safeJoin(PUB, p); return f ? serveFile(req, res, f, 'no-cache') : notFound(req, res); }
    if (path.extname(p)) { const f = safeJoin(PUB, p); return f && !f.endsWith('index.html') ? serveFile(req, res, f, /\.(css|js)$/.test(p) ? 'no-cache' : undefined) : notFound(req, res); }
    return servePage(req, res);
  } catch (e) {
    if (!res.headersSent) json(res, e.status || 500, { error: e.status ? e.message : 'Erro interno.' });
    if (!e.status) console.error(e);
  }
});
server.requestTimeout = 0; // uploads grandes
server.listen(PORT, HOST, () => console.log(`Letter no ar em http://${HOST}:${PORT}  ·  painel: /admin`));
